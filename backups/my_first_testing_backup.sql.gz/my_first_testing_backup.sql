--
-- PostgreSQL database dump
--

\restrict UCkUf9cntKaQAWhzKlB7sciGEbqO5RFDCwEFBCsxAXJtzsun28I8kcczluJhNdG

-- Dumped from database version 16.10
-- Dumped by pg_dump version 16.10

-- Started on 2025-11-16 00:08:21 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.packages_packageitinerary_activities DROP CONSTRAINT IF EXISTS packages_packageitin_packageitinerary_id_b89e2263_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_packageitinerary DROP CONSTRAINT IF EXISTS packages_packageitin_package_id_bf27c950_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_packageitinerary_activities DROP CONSTRAINT IF EXISTS packages_packageitin_activity_id_4c13150d_fk_activitie;
ALTER TABLE IF EXISTS ONLY public.packages_packageitinerary DROP CONSTRAINT IF EXISTS packages_packageitin_accommodation_id_9cd3b10a_fk_accommoda;
ALTER TABLE IF EXISTS ONLY public.packages_packageinclusion DROP CONSTRAINT IF EXISTS packages_packageincl_package_id_8199e68e_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_packageimage DROP CONSTRAINT IF EXISTS packages_packageimag_package_id_d6d4a11c_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_package_destinations DROP CONSTRAINT IF EXISTS packages_package_des_package_id_0006a3bf_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_package_destinations DROP CONSTRAINT IF EXISTS packages_package_des_destination_id_444f5bf3_fk_destinati;
ALTER TABLE IF EXISTS ONLY public.packages_package DROP CONSTRAINT IF EXISTS packages_package_created_by_id_58883b1d_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.packages_inquirymessage DROP CONSTRAINT IF EXISTS packages_inquirymess_sender_staff_id_03829bc7_fk_auth_user;
ALTER TABLE IF EXISTS ONLY public.packages_inquirymessage DROP CONSTRAINT IF EXISTS packages_inquirymess_inquiry_id_d0c696b4_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_custompackage DROP CONSTRAINT IF EXISTS packages_custompackage_created_by_id_67a8ded0_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.packages_custompackage DROP CONSTRAINT IF EXISTS packages_custompacka_last_modified_by_id_2b960063_fk_auth_user;
ALTER TABLE IF EXISTS ONLY public.packages_custompackage DROP CONSTRAINT IF EXISTS packages_custompacka_inquiry_id_d6cf9dcd_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_custompackageitinerary DROP CONSTRAINT IF EXISTS packages_custompacka_custom_package_id_acfeebd0_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_custompackage DROP CONSTRAINT IF EXISTS packages_custompacka_base_package_id_a8c81e39_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_bookinginquiry DROP CONSTRAINT IF EXISTS packages_bookinginqu_staff_assigned_id_fb2818cd_fk_auth_user;
ALTER TABLE IF EXISTS ONLY public.packages_bookinginquiry DROP CONSTRAINT IF EXISTS packages_bookinginqu_custom_package_id_034376cb_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.packages_bookinginquiry DROP CONSTRAINT IF EXISTS packages_bookinginqu_base_package_id_85ecb013_fk_packages_;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_user_id_c564eba6_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_content_type_id_c4bce8eb_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.destinations_destination DROP CONSTRAINT IF EXISTS destinations_destination_created_by_id_59073026_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.destinations_destinationimage DROP CONSTRAINT IF EXISTS destinations_destina_destination_id_6638a3f9_fk_destinati;
ALTER TABLE IF EXISTS ONLY public.core_testimonial DROP CONSTRAINT IF EXISTS core_testimonial_created_by_id_5f4550d7_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.core_faq DROP CONSTRAINT IF EXISTS core_faq_created_by_id_adb5a9d1_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_6a12ed8b_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_group_id_97559544_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_2f476e4b_fk_django_co;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_b120cbf9_fk_auth_group_id;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissio_permission_id_84c5c92e_fk_auth_perm;
ALTER TABLE IF EXISTS ONLY public.activities_activityimage DROP CONSTRAINT IF EXISTS activities_activityi_activity_id_869d42b9_fk_activitie;
ALTER TABLE IF EXISTS ONLY public.activities_activity DROP CONSTRAINT IF EXISTS activities_activity_destination_id_15d54268_fk_destinati;
ALTER TABLE IF EXISTS ONLY public.activities_activity DROP CONSTRAINT IF EXISTS activities_activity_created_by_id_b5334206_fk_auth_user_id;
ALTER TABLE IF EXISTS ONLY public.accommodations_room DROP CONSTRAINT IF EXISTS accommodations_room_accommodation_id_a7df23b4_fk_accommoda;
ALTER TABLE IF EXISTS ONLY public.accommodations_accommodation DROP CONSTRAINT IF EXISTS accommodations_accom_destination_id_47a4313c_fk_destinati;
ALTER TABLE IF EXISTS ONLY public.accommodations_accommodation DROP CONSTRAINT IF EXISTS accommodations_accom_created_by_id_4707283b_fk_auth_user;
ALTER TABLE IF EXISTS ONLY public.accommodations_accommodationimage DROP CONSTRAINT IF EXISTS accommodations_accom_accommodation_id_2816a277_fk_accommoda;
DROP INDEX IF EXISTS public.packages_packageitinerary_package_id_bf27c950;
DROP INDEX IF EXISTS public.packages_packageitinerary_activities_activity_id_4c13150d;
DROP INDEX IF EXISTS public.packages_packageitinerary_accommodation_id_9cd3b10a;
DROP INDEX IF EXISTS public.packages_packageitinerary__packageitinerary_id_b89e2263;
DROP INDEX IF EXISTS public.packages_packageinclusion_package_id_8199e68e;
DROP INDEX IF EXISTS public.packages_packageimage_package_id_d6d4a11c;
DROP INDEX IF EXISTS public.packages_package_slug_520189a0_like;
DROP INDEX IF EXISTS public.packages_package_order_e68c64b7;
DROP INDEX IF EXISTS public.packages_package_name_00867446_like;
DROP INDEX IF EXISTS public.packages_package_is_featured_27b1a3c3;
DROP INDEX IF EXISTS public.packages_package_is_active_e9d4e10f;
DROP INDEX IF EXISTS public.packages_package_difficulty_level_20e618a1_like;
DROP INDEX IF EXISTS public.packages_package_difficulty_level_20e618a1;
DROP INDEX IF EXISTS public.packages_package_destinations_package_id_0006a3bf;
DROP INDEX IF EXISTS public.packages_package_destinations_destination_id_444f5bf3;
DROP INDEX IF EXISTS public.packages_package_created_by_id_58883b1d;
DROP INDEX IF EXISTS public.packages_package_category_9b7db42d_like;
DROP INDEX IF EXISTS public.packages_package_category_9b7db42d;
DROP INDEX IF EXISTS public.packages_package_availability_status_d57d92f3_like;
DROP INDEX IF EXISTS public.packages_package_availability_status_d57d92f3;
DROP INDEX IF EXISTS public.packages_pa_price_p_bfe1c0_idx;
DROP INDEX IF EXISTS public.packages_pa_categor_b32184_idx;
DROP INDEX IF EXISTS public.packages_pa_availab_5e2aec_idx;
DROP INDEX IF EXISTS public.packages_inquirymessage_sender_staff_id_03829bc7;
DROP INDEX IF EXISTS public.packages_inquirymessage_inquiry_id_d0c696b4;
DROP INDEX IF EXISTS public.packages_custompackageitinerary_custom_package_id_acfeebd0;
DROP INDEX IF EXISTS public.packages_custompackage_last_modified_by_id_2b960063;
DROP INDEX IF EXISTS public.packages_custompackage_inquiry_id_d6cf9dcd;
DROP INDEX IF EXISTS public.packages_custompackage_custom_reference_92582306_like;
DROP INDEX IF EXISTS public.packages_custompackage_created_by_id_67a8ded0;
DROP INDEX IF EXISTS public.packages_custompackage_base_package_id_a8c81e39;
DROP INDEX IF EXISTS public.packages_cu_status_447856_idx;
DROP INDEX IF EXISTS public.packages_cu_inquiry_af79ac_idx;
DROP INDEX IF EXISTS public.packages_cu_access__bac2d3_idx;
DROP INDEX IF EXISTS public.packages_bookinginquiry_staff_assigned_id_fb2818cd;
DROP INDEX IF EXISTS public.packages_bookinginquiry_inquiry_reference_e3ef4692_like;
DROP INDEX IF EXISTS public.packages_bookinginquiry_custom_package_id_034376cb;
DROP INDEX IF EXISTS public.packages_bookinginquiry_base_package_id_85ecb013;
DROP INDEX IF EXISTS public.packages_bo_status_c5e1b6_idx;
DROP INDEX IF EXISTS public.packages_bo_staff_a_9e6f30_idx;
DROP INDEX IF EXISTS public.django_session_session_key_c0390e0f_like;
DROP INDEX IF EXISTS public.django_session_expire_date_a5c62663;
DROP INDEX IF EXISTS public.django_admin_log_user_id_c564eba6;
DROP INDEX IF EXISTS public.django_admin_log_content_type_id_c4bce8eb;
DROP INDEX IF EXISTS public.destinations_destinationimage_destination_id_6638a3f9;
DROP INDEX IF EXISTS public.destinations_destination_slug_92849aad_like;
DROP INDEX IF EXISTS public.destinations_destination_name_ec7860c8_like;
DROP INDEX IF EXISTS public.destinations_destination_is_featured_b6a0535b;
DROP INDEX IF EXISTS public.destinations_destination_is_active_6d875af2;
DROP INDEX IF EXISTS public.destinations_destination_created_by_id_59073026;
DROP INDEX IF EXISTS public.destinations_destination_country_ad986759_like;
DROP INDEX IF EXISTS public.destinations_destination_country_ad986759;
DROP INDEX IF EXISTS public.destination_order_5dbcec_idx;
DROP INDEX IF EXISTS public.destination_name_96ccc3_idx;
DROP INDEX IF EXISTS public.destination_is_feat_30ec6f_idx;
DROP INDEX IF EXISTS public.destination_country_2ade19_idx;
DROP INDEX IF EXISTS public.core_testimonial_order_79635763;
DROP INDEX IF EXISTS public.core_testimonial_is_featured_bd2d39d1;
DROP INDEX IF EXISTS public.core_testimonial_is_active_b5980b99;
DROP INDEX IF EXISTS public.core_testimonial_created_by_id_5f4550d7;
DROP INDEX IF EXISTS public.core_newslettersubscriber_is_active_9140439a;
DROP INDEX IF EXISTS public.core_newslettersubscriber_email_c9d9dbd8_like;
DROP INDEX IF EXISTS public.core_newsle_is_acti_899c52_idx;
DROP INDEX IF EXISTS public.core_newsle_email_c74825_idx;
DROP INDEX IF EXISTS public.core_faq_order_16bb6561;
DROP INDEX IF EXISTS public.core_faq_is_featured_3b63be95;
DROP INDEX IF EXISTS public.core_faq_is_active_5f13c3b6;
DROP INDEX IF EXISTS public.core_faq_created_by_id_adb5a9d1;
DROP INDEX IF EXISTS public.core_faq_category_5bf84efb_like;
DROP INDEX IF EXISTS public.core_faq_category_5bf84efb;
DROP INDEX IF EXISTS public.core_faq_categor_181b73_idx;
DROP INDEX IF EXISTS public.core_contactmessage_status_037e9912_like;
DROP INDEX IF EXISTS public.core_contactmessage_status_037e9912;
DROP INDEX IF EXISTS public.core_contac_status_a0adbc_idx;
DROP INDEX IF EXISTS public.core_contac_email_cfac76_idx;
DROP INDEX IF EXISTS public.auth_user_username_6821ab7c_like;
DROP INDEX IF EXISTS public.auth_user_user_permissions_user_id_a95ead1b;
DROP INDEX IF EXISTS public.auth_user_user_permissions_permission_id_1fbb5f2c;
DROP INDEX IF EXISTS public.auth_user_groups_user_id_6a12ed8b;
DROP INDEX IF EXISTS public.auth_user_groups_group_id_97559544;
DROP INDEX IF EXISTS public.auth_permission_content_type_id_2f476e4b;
DROP INDEX IF EXISTS public.auth_group_permissions_permission_id_84c5c92e;
DROP INDEX IF EXISTS public.auth_group_permissions_group_id_b120cbf9;
DROP INDEX IF EXISTS public.auth_group_name_a6ea08ec_like;
DROP INDEX IF EXISTS public.activities_activityimage_activity_id_869d42b9;
DROP INDEX IF EXISTS public.activities_activity_slug_15d2d0ee_like;
DROP INDEX IF EXISTS public.activities_activity_name_5ebe762e_like;
DROP INDEX IF EXISTS public.activities_activity_is_featured_f99b2415;
DROP INDEX IF EXISTS public.activities_activity_is_active_cacf458b;
DROP INDEX IF EXISTS public.activities_activity_difficulty_56206264_like;
DROP INDEX IF EXISTS public.activities_activity_difficulty_56206264;
DROP INDEX IF EXISTS public.activities_activity_destination_id_15d54268;
DROP INDEX IF EXISTS public.activities_activity_created_by_id_b5334206;
DROP INDEX IF EXISTS public.activities_activity_category_53f4bb81_like;
DROP INDEX IF EXISTS public.activities_activity_category_53f4bb81;
DROP INDEX IF EXISTS public.activities__order_31f2b4_idx;
DROP INDEX IF EXISTS public.activities__name_4db595_idx;
DROP INDEX IF EXISTS public.activities__is_feat_83a0dc_idx;
DROP INDEX IF EXISTS public.activities__destina_883bbe_idx;
DROP INDEX IF EXISTS public.activities__categor_00d5d1_idx;
DROP INDEX IF EXISTS public.accommodations_room_accommodation_id_a7df23b4;
DROP INDEX IF EXISTS public.accommodations_accommodationimage_accommodation_id_2816a277;
DROP INDEX IF EXISTS public.accommodations_accommodation_slug_f043abb8_like;
DROP INDEX IF EXISTS public.accommodations_accommodation_name_f3886e73_like;
DROP INDEX IF EXISTS public.accommodations_accommodation_is_featured_80e98a8f;
DROP INDEX IF EXISTS public.accommodations_accommodation_is_active_021f06d9;
DROP INDEX IF EXISTS public.accommodations_accommodation_destination_id_47a4313c;
DROP INDEX IF EXISTS public.accommodations_accommodation_created_by_id_4707283b;
DROP INDEX IF EXISTS public.accommodations_accommodation_accommodation_type_3b989931_like;
DROP INDEX IF EXISTS public.accommodations_accommodation_accommodation_type_3b989931;
DROP INDEX IF EXISTS public.accommodati_order_a62fa1_idx;
DROP INDEX IF EXISTS public.accommodati_name_a70e2a_idx;
DROP INDEX IF EXISTS public.accommodati_is_feat_c3e929_idx;
DROP INDEX IF EXISTS public.accommodati_destina_69bee5_idx;
DROP INDEX IF EXISTS public.accommodati_accommo_49a6d0_idx;
ALTER TABLE IF EXISTS ONLY public.packages_packageitinerary DROP CONSTRAINT IF EXISTS packages_packageitinerary_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_packageitinerary DROP CONSTRAINT IF EXISTS packages_packageitinerary_package_id_day_number_151ee79e_uniq;
ALTER TABLE IF EXISTS ONLY public.packages_packageitinerary_activities DROP CONSTRAINT IF EXISTS packages_packageitinerary_activities_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_packageitinerary_activities DROP CONSTRAINT IF EXISTS packages_packageitinerar_packageitinerary_id_acti_f37a0270_uniq;
ALTER TABLE IF EXISTS ONLY public.packages_packageinclusion DROP CONSTRAINT IF EXISTS packages_packageinclusion_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_packageimage DROP CONSTRAINT IF EXISTS packages_packageimage_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_package DROP CONSTRAINT IF EXISTS packages_package_slug_key;
ALTER TABLE IF EXISTS ONLY public.packages_package DROP CONSTRAINT IF EXISTS packages_package_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_package DROP CONSTRAINT IF EXISTS packages_package_name_key;
ALTER TABLE IF EXISTS ONLY public.packages_package_destinations DROP CONSTRAINT IF EXISTS packages_package_destinations_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_package_destinations DROP CONSTRAINT IF EXISTS packages_package_destina_package_id_destination_i_29c27924_uniq;
ALTER TABLE IF EXISTS ONLY public.packages_inquirymessage DROP CONSTRAINT IF EXISTS packages_inquirymessage_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_custompackageitinerary DROP CONSTRAINT IF EXISTS packages_custompackageitinerary_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_custompackageitinerary DROP CONSTRAINT IF EXISTS packages_custompackageit_custom_package_id_day_nu_a3713251_uniq;
ALTER TABLE IF EXISTS ONLY public.packages_custompackage DROP CONSTRAINT IF EXISTS packages_custompackage_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_custompackage DROP CONSTRAINT IF EXISTS packages_custompackage_custom_reference_key;
ALTER TABLE IF EXISTS ONLY public.packages_bookinginquiry DROP CONSTRAINT IF EXISTS packages_bookinginquiry_pkey;
ALTER TABLE IF EXISTS ONLY public.packages_bookinginquiry DROP CONSTRAINT IF EXISTS packages_bookinginquiry_inquiry_reference_key;
ALTER TABLE IF EXISTS ONLY public.django_session DROP CONSTRAINT IF EXISTS django_session_pkey;
ALTER TABLE IF EXISTS ONLY public.django_migrations DROP CONSTRAINT IF EXISTS django_migrations_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_pkey;
ALTER TABLE IF EXISTS ONLY public.django_content_type DROP CONSTRAINT IF EXISTS django_content_type_app_label_model_76bd3d3b_uniq;
ALTER TABLE IF EXISTS ONLY public.django_admin_log DROP CONSTRAINT IF EXISTS django_admin_log_pkey;
ALTER TABLE IF EXISTS ONLY public.destinations_destinationimage DROP CONSTRAINT IF EXISTS destinations_destinationimage_pkey;
ALTER TABLE IF EXISTS ONLY public.destinations_destination DROP CONSTRAINT IF EXISTS destinations_destination_slug_key;
ALTER TABLE IF EXISTS ONLY public.destinations_destination DROP CONSTRAINT IF EXISTS destinations_destination_pkey;
ALTER TABLE IF EXISTS ONLY public.destinations_destination DROP CONSTRAINT IF EXISTS destinations_destination_name_key;
ALTER TABLE IF EXISTS ONLY public.core_testimonial DROP CONSTRAINT IF EXISTS core_testimonial_pkey;
ALTER TABLE IF EXISTS ONLY public.core_newslettersubscriber DROP CONSTRAINT IF EXISTS core_newslettersubscriber_pkey;
ALTER TABLE IF EXISTS ONLY public.core_newslettersubscriber DROP CONSTRAINT IF EXISTS core_newslettersubscriber_email_key;
ALTER TABLE IF EXISTS ONLY public.core_faq DROP CONSTRAINT IF EXISTS core_faq_pkey;
ALTER TABLE IF EXISTS ONLY public.core_contactmessage DROP CONSTRAINT IF EXISTS core_contactmessage_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_username_key;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_user_id_permission_id_14a6b632_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_user_permissions DROP CONSTRAINT IF EXISTS auth_user_user_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user DROP CONSTRAINT IF EXISTS auth_user_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_user_id_group_id_94350c0c_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_user_groups DROP CONSTRAINT IF EXISTS auth_user_groups_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_permission DROP CONSTRAINT IF EXISTS auth_permission_content_type_id_codename_01ab375a_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_pkey;
ALTER TABLE IF EXISTS ONLY public.auth_group_permissions DROP CONSTRAINT IF EXISTS auth_group_permissions_group_id_permission_id_0cd325b0_uniq;
ALTER TABLE IF EXISTS ONLY public.auth_group DROP CONSTRAINT IF EXISTS auth_group_name_key;
ALTER TABLE IF EXISTS ONLY public.activities_activityimage DROP CONSTRAINT IF EXISTS activities_activityimage_pkey;
ALTER TABLE IF EXISTS ONLY public.activities_activity DROP CONSTRAINT IF EXISTS activities_activity_slug_key;
ALTER TABLE IF EXISTS ONLY public.activities_activity DROP CONSTRAINT IF EXISTS activities_activity_pkey;
ALTER TABLE IF EXISTS ONLY public.activities_activity DROP CONSTRAINT IF EXISTS activities_activity_name_key;
ALTER TABLE IF EXISTS ONLY public.accommodations_room DROP CONSTRAINT IF EXISTS accommodations_room_pkey;
ALTER TABLE IF EXISTS ONLY public.accommodations_accommodationimage DROP CONSTRAINT IF EXISTS accommodations_accommodationimage_pkey;
ALTER TABLE IF EXISTS ONLY public.accommodations_accommodation DROP CONSTRAINT IF EXISTS accommodations_accommodation_slug_key;
ALTER TABLE IF EXISTS ONLY public.accommodations_accommodation DROP CONSTRAINT IF EXISTS accommodations_accommodation_pkey;
ALTER TABLE IF EXISTS ONLY public.accommodations_accommodation DROP CONSTRAINT IF EXISTS accommodations_accommodation_name_key;
DROP TABLE IF EXISTS public.packages_packageitinerary_activities;
DROP TABLE IF EXISTS public.packages_packageitinerary;
DROP TABLE IF EXISTS public.packages_packageinclusion;
DROP TABLE IF EXISTS public.packages_packageimage;
DROP TABLE IF EXISTS public.packages_package_destinations;
DROP TABLE IF EXISTS public.packages_package;
DROP TABLE IF EXISTS public.packages_inquirymessage;
DROP TABLE IF EXISTS public.packages_custompackageitinerary;
DROP TABLE IF EXISTS public.packages_custompackage;
DROP TABLE IF EXISTS public.packages_bookinginquiry;
DROP TABLE IF EXISTS public.django_session;
DROP TABLE IF EXISTS public.django_migrations;
DROP TABLE IF EXISTS public.django_content_type;
DROP TABLE IF EXISTS public.django_admin_log;
DROP TABLE IF EXISTS public.destinations_destinationimage;
DROP TABLE IF EXISTS public.destinations_destination;
DROP TABLE IF EXISTS public.core_testimonial;
DROP TABLE IF EXISTS public.core_newslettersubscriber;
DROP TABLE IF EXISTS public.core_faq;
DROP TABLE IF EXISTS public.core_contactmessage;
DROP TABLE IF EXISTS public.auth_user_user_permissions;
DROP TABLE IF EXISTS public.auth_user_groups;
DROP TABLE IF EXISTS public.auth_user;
DROP TABLE IF EXISTS public.auth_permission;
DROP TABLE IF EXISTS public.auth_group_permissions;
DROP TABLE IF EXISTS public.auth_group;
DROP TABLE IF EXISTS public.activities_activityimage;
DROP TABLE IF EXISTS public.activities_activity;
DROP TABLE IF EXISTS public.accommodations_room;
DROP TABLE IF EXISTS public.accommodations_accommodationimage;
DROP TABLE IF EXISTS public.accommodations_accommodation;
SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 236 (class 1259 OID 16543)
-- Name: accommodations_accommodation; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.accommodations_accommodation (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    description text NOT NULL,
    short_description character varying(500) NOT NULL,
    accommodation_type character varying(50) NOT NULL,
    star_rating integer,
    address text NOT NULL,
    latitude numeric(9,6),
    longitude numeric(9,6),
    phone character varying(50) NOT NULL,
    email character varying(254) NOT NULL,
    website character varying(200) NOT NULL,
    amenities text NOT NULL,
    price_per_night_min numeric(10,2),
    price_per_night_max numeric(10,2),
    currency character varying(3) NOT NULL,
    featured_image character varying(100),
    video_url character varying(200),
    total_rooms integer,
    check_in_time character varying(50) NOT NULL,
    check_out_time character varying(50) NOT NULL,
    policies text NOT NULL,
    is_featured boolean NOT NULL,
    is_active boolean NOT NULL,
    view_count integer NOT NULL,
    "order" integer NOT NULL,
    meta_title character varying(200) NOT NULL,
    meta_description text NOT NULL,
    meta_keywords character varying(500) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by_id integer,
    destination_id bigint,
    CONSTRAINT accommodations_accommodation_total_rooms_check CHECK ((total_rooms >= 0)),
    CONSTRAINT accommodations_accommodation_view_count_check CHECK ((view_count >= 0))
);


ALTER TABLE public.accommodations_accommodation OWNER TO tour_admin;

--
-- TOC entry 235 (class 1259 OID 16542)
-- Name: accommodations_accommodation_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.accommodations_accommodation ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.accommodations_accommodation_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 238 (class 1259 OID 16557)
-- Name: accommodations_accommodationimage; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.accommodations_accommodationimage (
    id bigint NOT NULL,
    image character varying(100) NOT NULL,
    caption character varying(200) NOT NULL,
    "order" integer NOT NULL,
    uploaded_at timestamp with time zone NOT NULL,
    accommodation_id bigint NOT NULL
);


ALTER TABLE public.accommodations_accommodationimage OWNER TO tour_admin;

--
-- TOC entry 237 (class 1259 OID 16556)
-- Name: accommodations_accommodationimage_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.accommodations_accommodationimage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.accommodations_accommodationimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 240 (class 1259 OID 16563)
-- Name: accommodations_room; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.accommodations_room (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    room_type character varying(50) NOT NULL,
    description text NOT NULL,
    max_occupancy integer NOT NULL,
    bed_type character varying(50) NOT NULL,
    number_of_beds integer NOT NULL,
    size_sqm numeric(6,2),
    price_per_night numeric(10,2) NOT NULL,
    amenities text NOT NULL,
    is_available boolean NOT NULL,
    image character varying(100),
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    accommodation_id bigint NOT NULL,
    CONSTRAINT accommodations_room_max_occupancy_check CHECK ((max_occupancy >= 0)),
    CONSTRAINT accommodations_room_number_of_beds_check CHECK ((number_of_beds >= 0))
);


ALTER TABLE public.accommodations_room OWNER TO tour_admin;

--
-- TOC entry 239 (class 1259 OID 16562)
-- Name: accommodations_room_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.accommodations_room ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.accommodations_room_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 242 (class 1259 OID 16613)
-- Name: activities_activity; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.activities_activity (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    description text NOT NULL,
    short_description character varying(500) NOT NULL,
    category character varying(50) NOT NULL,
    difficulty character varying(20) NOT NULL,
    duration numeric(5,1) NOT NULL,
    duration_unit character varying(10) NOT NULL,
    min_age integer,
    max_group_size integer,
    price_per_person numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    featured_image character varying(100),
    video_url character varying(200),
    requirements text NOT NULL,
    included_items text NOT NULL,
    excluded_items text NOT NULL,
    best_season character varying(255) NOT NULL,
    is_featured boolean NOT NULL,
    is_active boolean NOT NULL,
    view_count integer NOT NULL,
    "order" integer NOT NULL,
    meta_title character varying(200) NOT NULL,
    meta_description text NOT NULL,
    meta_keywords character varying(500) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by_id integer,
    destination_id bigint NOT NULL,
    CONSTRAINT activities_activity_max_group_size_check CHECK ((max_group_size >= 0)),
    CONSTRAINT activities_activity_min_age_check CHECK ((min_age >= 0)),
    CONSTRAINT activities_activity_view_count_check CHECK ((view_count >= 0))
);


ALTER TABLE public.activities_activity OWNER TO tour_admin;

--
-- TOC entry 241 (class 1259 OID 16612)
-- Name: activities_activity_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.activities_activity ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.activities_activity_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 244 (class 1259 OID 16628)
-- Name: activities_activityimage; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.activities_activityimage (
    id bigint NOT NULL,
    image character varying(100) NOT NULL,
    caption character varying(200) NOT NULL,
    "order" integer NOT NULL,
    uploaded_at timestamp with time zone NOT NULL,
    activity_id bigint NOT NULL
);


ALTER TABLE public.activities_activityimage OWNER TO tour_admin;

--
-- TOC entry 243 (class 1259 OID 16627)
-- Name: activities_activityimage_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.activities_activityimage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.activities_activityimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 222 (class 1259 OID 16408)
-- Name: auth_group; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


ALTER TABLE public.auth_group OWNER TO tour_admin;

--
-- TOC entry 221 (class 1259 OID 16407)
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 224 (class 1259 OID 16416)
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_group_permissions OWNER TO tour_admin;

--
-- TOC entry 223 (class 1259 OID 16415)
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 220 (class 1259 OID 16402)
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


ALTER TABLE public.auth_permission OWNER TO tour_admin;

--
-- TOC entry 219 (class 1259 OID 16401)
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 226 (class 1259 OID 16422)
-- Name: auth_user; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.auth_user (
    id integer NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


ALTER TABLE public.auth_user OWNER TO tour_admin;

--
-- TOC entry 228 (class 1259 OID 16430)
-- Name: auth_user_groups; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.auth_user_groups (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    group_id integer NOT NULL
);


ALTER TABLE public.auth_user_groups OWNER TO tour_admin;

--
-- TOC entry 227 (class 1259 OID 16429)
-- Name: auth_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.auth_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 225 (class 1259 OID 16421)
-- Name: auth_user_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.auth_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 230 (class 1259 OID 16436)
-- Name: auth_user_user_permissions; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.auth_user_user_permissions (
    id bigint NOT NULL,
    user_id integer NOT NULL,
    permission_id integer NOT NULL
);


ALTER TABLE public.auth_user_user_permissions OWNER TO tour_admin;

--
-- TOC entry 229 (class 1259 OID 16435)
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.auth_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 248 (class 1259 OID 16694)
-- Name: core_contactmessage; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.core_contactmessage (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    name character varying(200) NOT NULL,
    email character varying(254) NOT NULL,
    phone character varying(20) NOT NULL,
    subject character varying(200) NOT NULL,
    message text NOT NULL,
    status character varying(20) NOT NULL,
    admin_notes text NOT NULL,
    ip_address inet
);


ALTER TABLE public.core_contactmessage OWNER TO tour_admin;

--
-- TOC entry 247 (class 1259 OID 16693)
-- Name: core_contactmessage_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.core_contactmessage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_contactmessage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 254 (class 1259 OID 16720)
-- Name: core_faq; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.core_faq (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    is_featured boolean NOT NULL,
    "order" integer NOT NULL,
    category character varying(50) NOT NULL,
    question character varying(500) NOT NULL,
    answer text NOT NULL,
    created_by_id integer
);


ALTER TABLE public.core_faq OWNER TO tour_admin;

--
-- TOC entry 253 (class 1259 OID 16719)
-- Name: core_faq_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.core_faq ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_faq_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 250 (class 1259 OID 16702)
-- Name: core_newslettersubscriber; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.core_newslettersubscriber (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    email character varying(254) NOT NULL,
    name character varying(200) NOT NULL,
    is_active boolean NOT NULL,
    unsubscribed_at timestamp with time zone,
    ip_address inet
);


ALTER TABLE public.core_newslettersubscriber OWNER TO tour_admin;

--
-- TOC entry 249 (class 1259 OID 16701)
-- Name: core_newslettersubscriber_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.core_newslettersubscriber ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_newslettersubscriber_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 252 (class 1259 OID 16712)
-- Name: core_testimonial; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.core_testimonial (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    is_active boolean NOT NULL,
    is_featured boolean NOT NULL,
    "order" integer NOT NULL,
    customer_name character varying(200) NOT NULL,
    customer_location character varying(200) NOT NULL,
    customer_image character varying(100),
    quote text NOT NULL,
    rating integer NOT NULL,
    created_by_id integer
);


ALTER TABLE public.core_testimonial OWNER TO tour_admin;

--
-- TOC entry 251 (class 1259 OID 16711)
-- Name: core_testimonial_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.core_testimonial ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_testimonial_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 232 (class 1259 OID 16498)
-- Name: destinations_destination; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.destinations_destination (
    id bigint NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    description text NOT NULL,
    short_description character varying(500) NOT NULL,
    country character varying(100) NOT NULL,
    region character varying(100) NOT NULL,
    latitude numeric(9,6) NOT NULL,
    longitude numeric(9,6) NOT NULL,
    featured_image character varying(100) NOT NULL,
    video_url character varying(200) NOT NULL,
    best_time_to_visit character varying(100) NOT NULL,
    climate text NOT NULL,
    wildlife text NOT NULL,
    is_featured boolean NOT NULL,
    is_active boolean NOT NULL,
    view_count integer NOT NULL,
    "order" integer NOT NULL,
    meta_title character varying(200) NOT NULL,
    meta_description text NOT NULL,
    meta_keywords character varying(500) NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    created_by_id integer,
    CONSTRAINT destinations_destination_view_count_check CHECK ((view_count >= 0))
);


ALTER TABLE public.destinations_destination OWNER TO tour_admin;

--
-- TOC entry 231 (class 1259 OID 16497)
-- Name: destinations_destination_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.destinations_destination ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.destinations_destination_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 234 (class 1259 OID 16511)
-- Name: destinations_destinationimage; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.destinations_destinationimage (
    id bigint NOT NULL,
    image character varying(100) NOT NULL,
    caption character varying(200) NOT NULL,
    "order" integer NOT NULL,
    uploaded_at timestamp with time zone NOT NULL,
    destination_id bigint NOT NULL
);


ALTER TABLE public.destinations_destinationimage OWNER TO tour_admin;

--
-- TOC entry 233 (class 1259 OID 16510)
-- Name: destinations_destinationimage_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.destinations_destinationimage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.destinations_destinationimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 246 (class 1259 OID 16665)
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id integer NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


ALTER TABLE public.django_admin_log OWNER TO tour_admin;

--
-- TOC entry 245 (class 1259 OID 16664)
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 218 (class 1259 OID 16394)
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


ALTER TABLE public.django_content_type OWNER TO tour_admin;

--
-- TOC entry 217 (class 1259 OID 16393)
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 216 (class 1259 OID 16386)
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


ALTER TABLE public.django_migrations OWNER TO tour_admin;

--
-- TOC entry 215 (class 1259 OID 16385)
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 267 (class 1259 OID 16886)
-- Name: django_session; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


ALTER TABLE public.django_session OWNER TO tour_admin;

--
-- TOC entry 269 (class 1259 OID 16901)
-- Name: packages_bookinginquiry; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_bookinginquiry (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    inquiry_reference character varying(50) NOT NULL,
    customer_name character varying(200) NOT NULL,
    customer_email character varying(254) NOT NULL,
    customer_phone character varying(50) NOT NULL,
    country character varying(100) NOT NULL,
    source character varying(100) NOT NULL,
    preferred_travel_date date,
    flexible_dates boolean NOT NULL,
    alternative_date_1 date,
    alternative_date_2 date,
    number_of_adults integer NOT NULL,
    number_of_children integer NOT NULL,
    number_of_infants integer NOT NULL,
    budget_range character varying(50) NOT NULL,
    specific_budget numeric(10,2),
    accommodation_preference character varying(50) NOT NULL,
    dietary_requirements text NOT NULL,
    special_requests text NOT NULL,
    prefer_email boolean NOT NULL,
    prefer_phone boolean NOT NULL,
    prefer_whatsapp boolean NOT NULL,
    status character varying(50) NOT NULL,
    priority character varying(50) NOT NULL,
    staff_notes text NOT NULL,
    viewed_by_staff boolean NOT NULL,
    first_viewed_at timestamp with time zone,
    last_activity_at timestamp with time zone NOT NULL,
    ip_address inet,
    base_package_id bigint,
    staff_assigned_id integer,
    custom_package_id bigint,
    CONSTRAINT packages_bookinginquiry_number_of_adults_check CHECK ((number_of_adults >= 0)),
    CONSTRAINT packages_bookinginquiry_number_of_children_check CHECK ((number_of_children >= 0)),
    CONSTRAINT packages_bookinginquiry_number_of_infants_check CHECK ((number_of_infants >= 0))
);


ALTER TABLE public.packages_bookinginquiry OWNER TO tour_admin;

--
-- TOC entry 268 (class 1259 OID 16900)
-- Name: packages_bookinginquiry_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_bookinginquiry ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_bookinginquiry_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 271 (class 1259 OID 16914)
-- Name: packages_custompackage; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_custompackage (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    custom_reference character varying(50) NOT NULL,
    access_token uuid NOT NULL,
    expires_at timestamp with time zone,
    name character varying(200) NOT NULL,
    short_description text NOT NULL,
    description text NOT NULL,
    duration_days integer NOT NULL,
    duration_nights integer NOT NULL,
    original_price numeric(10,2) NOT NULL,
    adjusted_price numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    modifications_made text NOT NULL,
    staff_notes_to_client text NOT NULL,
    staff_internal_notes text NOT NULL,
    status character varying(50) NOT NULL,
    sent_at timestamp with time zone,
    first_viewed_at timestamp with time zone,
    last_viewed_at timestamp with time zone,
    view_count integer NOT NULL,
    approved_at timestamp with time zone,
    rejected_at timestamp with time zone,
    client_feedback text NOT NULL,
    revision_number integer NOT NULL,
    featured_image character varying(100),
    base_package_id bigint,
    created_by_id integer,
    inquiry_id bigint NOT NULL,
    last_modified_by_id integer,
    CONSTRAINT packages_custompackage_duration_days_check CHECK ((duration_days >= 0)),
    CONSTRAINT packages_custompackage_duration_nights_check CHECK ((duration_nights >= 0)),
    CONSTRAINT packages_custompackage_revision_number_check CHECK ((revision_number >= 0)),
    CONSTRAINT packages_custompackage_view_count_check CHECK ((view_count >= 0))
);


ALTER TABLE public.packages_custompackage OWNER TO tour_admin;

--
-- TOC entry 270 (class 1259 OID 16913)
-- Name: packages_custompackage_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_custompackage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_custompackage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 275 (class 1259 OID 16998)
-- Name: packages_custompackageitinerary; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_custompackageitinerary (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    day_number integer NOT NULL,
    end_day_number integer,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    location character varying(200) NOT NULL,
    accommodation_name character varying(200) NOT NULL,
    accommodation_type character varying(50) NOT NULL,
    activities text NOT NULL,
    breakfast_included boolean NOT NULL,
    lunch_included boolean NOT NULL,
    dinner_included boolean NOT NULL,
    transport_details character varying(200) NOT NULL,
    distance character varying(100) NOT NULL,
    drive_time character varying(100) NOT NULL,
    featured_image character varying(100),
    "order" integer NOT NULL,
    is_active boolean NOT NULL,
    custom_package_id bigint NOT NULL,
    CONSTRAINT packages_custompackageitinerary_day_number_check CHECK ((day_number >= 0)),
    CONSTRAINT packages_custompackageitinerary_end_day_number_check CHECK ((end_day_number >= 0)),
    CONSTRAINT packages_custompackageitinerary_order_check CHECK (("order" >= 0))
);


ALTER TABLE public.packages_custompackageitinerary OWNER TO tour_admin;

--
-- TOC entry 274 (class 1259 OID 16997)
-- Name: packages_custompackageitinerary_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_custompackageitinerary ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_custompackageitinerary_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 273 (class 1259 OID 16933)
-- Name: packages_inquirymessage; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_inquirymessage (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    sender_email character varying(254) NOT NULL,
    sender_name character varying(200) NOT NULL,
    subject character varying(200) NOT NULL,
    message text NOT NULL,
    attachment character varying(100),
    is_internal boolean NOT NULL,
    is_automated boolean NOT NULL,
    is_read boolean NOT NULL,
    read_at timestamp with time zone,
    inquiry_id bigint NOT NULL,
    sender_staff_id integer
);


ALTER TABLE public.packages_inquirymessage OWNER TO tour_admin;

--
-- TOC entry 272 (class 1259 OID 16932)
-- Name: packages_inquirymessage_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_inquirymessage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_inquirymessage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 256 (class 1259 OID 16757)
-- Name: packages_package; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_package (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    meta_title character varying(200) NOT NULL,
    meta_description text NOT NULL,
    meta_keywords character varying(500) NOT NULL,
    is_active boolean NOT NULL,
    is_featured boolean NOT NULL,
    "order" integer NOT NULL,
    view_count integer NOT NULL,
    name character varying(200) NOT NULL,
    slug character varying(200) NOT NULL,
    description text NOT NULL,
    short_description character varying(300) NOT NULL,
    highlights text NOT NULL,
    duration_days integer NOT NULL,
    duration_nights integer NOT NULL,
    category character varying(50) NOT NULL,
    difficulty_level character varying(20) NOT NULL,
    group_size_min integer NOT NULL,
    group_size_max integer NOT NULL,
    price_per_person numeric(10,2) NOT NULL,
    currency character varying(3) NOT NULL,
    discount_percentage numeric(5,2) NOT NULL,
    availability_status character varying(20) NOT NULL,
    start_date date,
    end_date date,
    max_bookings integer NOT NULL,
    current_bookings integer NOT NULL,
    included_items text NOT NULL,
    excluded_items text NOT NULL,
    requirements text NOT NULL,
    cancellation_policy text NOT NULL,
    terms_and_conditions text NOT NULL,
    featured_image character varying(100),
    video_url character varying(200),
    is_customizable boolean NOT NULL,
    booking_count integer NOT NULL,
    rating_average numeric(3,2) NOT NULL,
    review_count integer NOT NULL,
    created_by_id integer,
    CONSTRAINT packages_package_booking_count_check CHECK ((booking_count >= 0)),
    CONSTRAINT packages_package_current_bookings_check CHECK ((current_bookings >= 0)),
    CONSTRAINT packages_package_duration_days_check CHECK ((duration_days >= 0)),
    CONSTRAINT packages_package_duration_nights_check CHECK ((duration_nights >= 0)),
    CONSTRAINT packages_package_group_size_max_check CHECK ((group_size_max >= 0)),
    CONSTRAINT packages_package_group_size_min_check CHECK ((group_size_min >= 0)),
    CONSTRAINT packages_package_max_bookings_check CHECK ((max_bookings >= 0)),
    CONSTRAINT packages_package_review_count_check CHECK ((review_count >= 0)),
    CONSTRAINT packages_package_view_count_check CHECK ((view_count >= 0))
);


ALTER TABLE public.packages_package OWNER TO tour_admin;

--
-- TOC entry 258 (class 1259 OID 16778)
-- Name: packages_package_destinations; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_package_destinations (
    id bigint NOT NULL,
    package_id bigint NOT NULL,
    destination_id bigint NOT NULL
);


ALTER TABLE public.packages_package_destinations OWNER TO tour_admin;

--
-- TOC entry 257 (class 1259 OID 16777)
-- Name: packages_package_destinations_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_package_destinations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_package_destinations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 255 (class 1259 OID 16756)
-- Name: packages_package_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_package ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_package_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 260 (class 1259 OID 16784)
-- Name: packages_packageimage; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_packageimage (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    image character varying(100) NOT NULL,
    caption character varying(200) NOT NULL,
    "order" integer NOT NULL,
    is_active boolean NOT NULL,
    package_id bigint NOT NULL
);


ALTER TABLE public.packages_packageimage OWNER TO tour_admin;

--
-- TOC entry 259 (class 1259 OID 16783)
-- Name: packages_packageimage_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_packageimage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_packageimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 262 (class 1259 OID 16790)
-- Name: packages_packageinclusion; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_packageinclusion (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    inclusion_type character varying(50) NOT NULL,
    item_name character varying(200) NOT NULL,
    description text NOT NULL,
    quantity character varying(100) NOT NULL,
    is_included boolean NOT NULL,
    "order" integer NOT NULL,
    is_active boolean NOT NULL,
    package_id bigint NOT NULL
);


ALTER TABLE public.packages_packageinclusion OWNER TO tour_admin;

--
-- TOC entry 261 (class 1259 OID 16789)
-- Name: packages_packageinclusion_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_packageinclusion ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_packageinclusion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 264 (class 1259 OID 16798)
-- Name: packages_packageitinerary; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_packageitinerary (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    day_number integer NOT NULL,
    title character varying(200) NOT NULL,
    description text NOT NULL,
    breakfast_included boolean NOT NULL,
    lunch_included boolean NOT NULL,
    dinner_included boolean NOT NULL,
    highlights character varying(500) NOT NULL,
    notes text NOT NULL,
    "order" integer NOT NULL,
    is_active boolean NOT NULL,
    accommodation_id bigint,
    package_id bigint NOT NULL,
    end_day_number integer,
    CONSTRAINT packages_packageitinerary_day_number_check CHECK ((day_number >= 0)),
    CONSTRAINT packages_packageitinerary_end_day_number_check CHECK ((end_day_number >= 0))
);


ALTER TABLE public.packages_packageitinerary OWNER TO tour_admin;

--
-- TOC entry 266 (class 1259 OID 16807)
-- Name: packages_packageitinerary_activities; Type: TABLE; Schema: public; Owner: tour_admin
--

CREATE TABLE public.packages_packageitinerary_activities (
    id bigint NOT NULL,
    packageitinerary_id bigint NOT NULL,
    activity_id bigint NOT NULL
);


ALTER TABLE public.packages_packageitinerary_activities OWNER TO tour_admin;

--
-- TOC entry 265 (class 1259 OID 16806)
-- Name: packages_packageitinerary_activities_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_packageitinerary_activities ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_packageitinerary_activities_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 263 (class 1259 OID 16797)
-- Name: packages_packageitinerary_id_seq; Type: SEQUENCE; Schema: public; Owner: tour_admin
--

ALTER TABLE public.packages_packageitinerary ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.packages_packageitinerary_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- TOC entry 3867 (class 0 OID 16543)
-- Dependencies: 236
-- Data for Name: accommodations_accommodation; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.accommodations_accommodation (id, name, slug, description, short_description, accommodation_type, star_rating, address, latitude, longitude, phone, email, website, amenities, price_per_night_min, price_per_night_max, currency, featured_image, video_url, total_rooms, check_in_time, check_out_time, policies, is_featured, is_active, view_count, "order", meta_title, meta_description, meta_keywords, created_at, updated_at, created_by_id, destination_id) FROM stdin;
1	Trever Erdman	trever-erdman	Hershel Medhurst	Quam aliquam ullam repellat fugiat pariatur.	hostel	3	84774 Oberbrunner Harbors	14.000000	50.000000	164-605-9766	your.email+fakedata17973@gmail.com		Swimming Pool, Room Service, Conference Facilities, Pet Friendly, Garden, Kids Club, Babysitting, Concierge, Free Breakfast	298.00	189.00	USD		\N	1	2026-06-10 13:54:57	2025-11-16 03:57:26	Rem sit incidunt.	t	t	0	1	Trever Erdman			2025-11-15 13:09:54.29693+00	2025-11-15 13:09:54.296962+00	1	1
\.


--
-- TOC entry 3869 (class 0 OID 16557)
-- Dependencies: 238
-- Data for Name: accommodations_accommodationimage; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.accommodations_accommodationimage (id, image, caption, "order", uploaded_at, accommodation_id) FROM stdin;
\.


--
-- TOC entry 3871 (class 0 OID 16563)
-- Dependencies: 240
-- Data for Name: accommodations_room; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.accommodations_room (id, name, room_type, description, max_occupancy, bed_type, number_of_beds, size_sqm, price_per_night, amenities, is_available, image, created_at, updated_at, accommodation_id) FROM stdin;
\.


--
-- TOC entry 3873 (class 0 OID 16613)
-- Dependencies: 242
-- Data for Name: activities_activity; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.activities_activity (id, name, slug, description, short_description, category, difficulty, duration, duration_unit, min_age, max_group_size, price_per_person, currency, featured_image, video_url, requirements, included_items, excluded_items, best_season, is_featured, is_active, view_count, "order", meta_title, meta_description, meta_keywords, created_at, updated_at, created_by_id, destination_id) FROM stdin;
1	Emory Baumbach	emory-baumbach	Hillard Sipes	Adipisci ratione inventore expedita et molestias modi.	bird_watching	extreme	1.0	hours	4	4	611.00	USD	activities/featured/Arusha_National_Park_2.jpg	\N	Nemo facilis culpa nobis quae alias ullam corrupti.	Numquam aperiam voluptatem id dignissimos perferendis nulla ex laborum.	Quo deserunt nesciunt sapiente maiores saepe id consequatur quod tempora.	59025 Fausto Way	t	t	0	1	Emory Baumbach			2025-11-15 22:25:54.114738+00	2025-11-15 22:25:54.114761+00	1	2
\.


--
-- TOC entry 3875 (class 0 OID 16628)
-- Dependencies: 244
-- Data for Name: activities_activityimage; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.activities_activityimage (id, image, caption, "order", uploaded_at, activity_id) FROM stdin;
\.


--
-- TOC entry 3853 (class 0 OID 16408)
-- Dependencies: 222
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- TOC entry 3855 (class 0 OID 16416)
-- Dependencies: 224
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- TOC entry 3851 (class 0 OID 16402)
-- Dependencies: 220
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add user	4	add_user
14	Can change user	4	change_user
15	Can delete user	4	delete_user
16	Can view user	4	view_user
17	Can add content type	5	add_contenttype
18	Can change content type	5	change_contenttype
19	Can delete content type	5	delete_contenttype
20	Can view content type	5	view_contenttype
21	Can add session	6	add_session
22	Can change session	6	change_session
23	Can delete session	6	delete_session
24	Can view session	6	view_session
25	Can add Contact Message	7	add_contactmessage
26	Can change Contact Message	7	change_contactmessage
27	Can delete Contact Message	7	delete_contactmessage
28	Can view Contact Message	7	view_contactmessage
29	Can add Newsletter Subscriber	8	add_newslettersubscriber
30	Can change Newsletter Subscriber	8	change_newslettersubscriber
31	Can delete Newsletter Subscriber	8	delete_newslettersubscriber
32	Can view Newsletter Subscriber	8	view_newslettersubscriber
33	Can add Testimonial	9	add_testimonial
34	Can change Testimonial	9	change_testimonial
35	Can delete Testimonial	9	delete_testimonial
36	Can view Testimonial	9	view_testimonial
37	Can add FAQ	10	add_faq
38	Can change FAQ	10	change_faq
39	Can delete FAQ	10	delete_faq
40	Can view FAQ	10	view_faq
41	Can add Destination	11	add_destination
42	Can change Destination	11	change_destination
43	Can delete Destination	11	delete_destination
44	Can view Destination	11	view_destination
45	Can add Destination Image	12	add_destinationimage
46	Can change Destination Image	12	change_destinationimage
47	Can delete Destination Image	12	delete_destinationimage
48	Can view Destination Image	12	view_destinationimage
49	Can add Accommodation	13	add_accommodation
50	Can change Accommodation	13	change_accommodation
51	Can delete Accommodation	13	delete_accommodation
52	Can view Accommodation	13	view_accommodation
53	Can add Accommodation Image	14	add_accommodationimage
54	Can change Accommodation Image	14	change_accommodationimage
55	Can delete Accommodation Image	14	delete_accommodationimage
56	Can view Accommodation Image	14	view_accommodationimage
57	Can add Room	15	add_room
58	Can change Room	15	change_room
59	Can delete Room	15	delete_room
60	Can view Room	15	view_room
61	Can add Package	16	add_package
62	Can change Package	16	change_package
63	Can delete Package	16	delete_package
64	Can view Package	16	view_package
65	Can add Package Image	17	add_packageimage
66	Can change Package Image	17	change_packageimage
67	Can delete Package Image	17	delete_packageimage
68	Can view Package Image	17	view_packageimage
69	Can add Package Inclusion	18	add_packageinclusion
70	Can change Package Inclusion	18	change_packageinclusion
71	Can delete Package Inclusion	18	delete_packageinclusion
72	Can view Package Inclusion	18	view_packageinclusion
73	Can add Package Itinerary	19	add_packageitinerary
74	Can change Package Itinerary	19	change_packageitinerary
75	Can delete Package Itinerary	19	delete_packageitinerary
76	Can view Package Itinerary	19	view_packageitinerary
77	Can add Activity	20	add_activity
78	Can change Activity	20	change_activity
79	Can delete Activity	20	delete_activity
80	Can view Activity	20	view_activity
81	Can add Activity Image	21	add_activityimage
82	Can change Activity Image	21	change_activityimage
83	Can delete Activity Image	21	delete_activityimage
84	Can view Activity Image	21	view_activityimage
85	Can add Booking Inquiry	22	add_bookinginquiry
86	Can change Booking Inquiry	22	change_bookinginquiry
87	Can delete Booking Inquiry	22	delete_bookinginquiry
88	Can view Booking Inquiry	22	view_bookinginquiry
89	Can add Custom Package	23	add_custompackage
90	Can change Custom Package	23	change_custompackage
91	Can delete Custom Package	23	delete_custompackage
92	Can view Custom Package	23	view_custompackage
93	Can add Inquiry Message	24	add_inquirymessage
94	Can change Inquiry Message	24	change_inquirymessage
95	Can delete Inquiry Message	24	delete_inquirymessage
96	Can view Inquiry Message	24	view_inquirymessage
97	Can add Custom Package Itinerary Day	25	add_custompackageitinerary
98	Can change Custom Package Itinerary Day	25	change_custompackageitinerary
99	Can delete Custom Package Itinerary Day	25	delete_custompackageitinerary
100	Can view Custom Package Itinerary Day	25	view_custompackageitinerary
\.


--
-- TOC entry 3857 (class 0 OID 16422)
-- Dependencies: 226
-- Data for Name: auth_user; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.auth_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$1000000$9NZsQzbPGjToG6p51UG47Z$2XO1K9Z783ktdVvdS9DRMbQoE+asG5Au1aAeY/Rn1Oc=	2025-11-13 23:50:27.349475+00	t	tour_admin				t	t	2025-11-13 23:50:19.651136+00
\.


--
-- TOC entry 3859 (class 0 OID 16430)
-- Dependencies: 228
-- Data for Name: auth_user_groups; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.auth_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- TOC entry 3861 (class 0 OID 16436)
-- Dependencies: 230
-- Data for Name: auth_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.auth_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- TOC entry 3879 (class 0 OID 16694)
-- Dependencies: 248
-- Data for Name: core_contactmessage; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.core_contactmessage (id, created_at, updated_at, name, email, phone, subject, message, status, admin_notes, ip_address) FROM stdin;
\.


--
-- TOC entry 3885 (class 0 OID 16720)
-- Dependencies: 254
-- Data for Name: core_faq; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.core_faq (id, created_at, updated_at, is_active, is_featured, "order", category, question, answer, created_by_id) FROM stdin;
\.


--
-- TOC entry 3881 (class 0 OID 16702)
-- Dependencies: 250
-- Data for Name: core_newslettersubscriber; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.core_newslettersubscriber (id, created_at, updated_at, email, name, is_active, unsubscribed_at, ip_address) FROM stdin;
\.


--
-- TOC entry 3883 (class 0 OID 16712)
-- Dependencies: 252
-- Data for Name: core_testimonial; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.core_testimonial (id, created_at, updated_at, is_active, is_featured, "order", customer_name, customer_location, customer_image, quote, rating, created_by_id) FROM stdin;
\.


--
-- TOC entry 3863 (class 0 OID 16498)
-- Dependencies: 232
-- Data for Name: destinations_destination; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.destinations_destination (id, name, slug, description, short_description, country, region, latitude, longitude, featured_image, video_url, best_time_to_visit, climate, wildlife, is_featured, is_active, view_count, "order", meta_title, meta_description, meta_keywords, created_at, updated_at, created_by_id) FROM stdin;
1	serengeti national park	serengeti-national-park	serengeti national park	serengeti national park	Tanzania	Arusha	54.000000	97.000000	destinations/featured/Serengeti_National_Park_1.jpg		2025-02-15 01:11:50	serengeti national park	Lions, elephants	t	t	1	0	serengeti national park			2025-11-14 20:46:28.952199+00	2025-11-14 20:46:28.952347+00	1
2	Arusha National Park	arusha-national-park	Arusha national park Arusha national park Arusha national park Arusha national park Arusha national park	Arusha national park	Tanzania	Arusha	54.000000	97.000000	destinations/featured/Arusha_National_Park_2.jpg		2025-02-15 01:11:50	normal	baboons	f	t	2	0	Arusha National Park			2025-11-14 20:59:44.90771+00	2025-11-14 20:59:44.908168+00	1
3	Thora Parker	thora-parker	Garry Cormier	Eaque fugiat illum ex aspernatur illum ullam optio illum temporibus.	Montenegro	Hawaii	41.000000	35.000000	destinations/featured/Bagamoyo_2.jpg		2024-11-28 21:04:16	2025-03-02 11:36:24uuuuu	Repellat dicta eaque quibusdam tempore unde odio.	f	f	0	2	Thora Parker			2025-11-15 22:59:47.55495+00	2025-11-15 22:59:47.554989+00	1
\.


--
-- TOC entry 3865 (class 0 OID 16511)
-- Dependencies: 234
-- Data for Name: destinations_destinationimage; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.destinations_destinationimage (id, image, caption, "order", uploaded_at, destination_id) FROM stdin;
1	destinations/gallery/Arusha_National_Park_1.jpg		0	2025-11-14 21:02:33.926437+00	2
2	destinations/gallery/Arusha_National_Park_2.jpg		0	2025-11-14 21:03:21.896905+00	2
3	destinations/gallery/Arusha_National_Park_3.jpg		0	2025-11-14 21:03:34.349023+00	2
4	destinations/gallery/Arusha_National_Park_4.jpg		0	2025-11-14 21:03:45.935362+00	2
\.


--
-- TOC entry 3877 (class 0 OID 16665)
-- Dependencies: 246
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- TOC entry 3849 (class 0 OID 16394)
-- Dependencies: 218
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	auth	user
5	contenttypes	contenttype
6	sessions	session
7	core	contactmessage
8	core	newslettersubscriber
9	core	testimonial
10	core	faq
11	destinations	destination
12	destinations	destinationimage
13	accommodations	accommodation
14	accommodations	accommodationimage
15	accommodations	room
16	packages	package
17	packages	packageimage
18	packages	packageinclusion
19	packages	packageitinerary
20	activities	activity
21	activities	activityimage
22	packages	bookinginquiry
23	packages	custompackage
24	packages	inquirymessage
25	packages	custompackageitinerary
\.


--
-- TOC entry 3847 (class 0 OID 16386)
-- Dependencies: 216
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2025-11-13 23:39:22.534059+00
2	auth	0001_initial	2025-11-13 23:39:22.703192+00
3	destinations	0001_initial	2025-11-13 23:39:22.931001+00
4	accommodations	0001_initial	2025-11-13 23:39:23.587301+00
5	accommodations	0002_alter_accommodation_destination	2025-11-13 23:39:23.648038+00
6	activities	0001_initial	2025-11-13 23:39:24.135061+00
7	admin	0001_initial	2025-11-13 23:39:24.198106+00
8	admin	0002_logentry_remove_auto_add	2025-11-13 23:39:24.233624+00
9	admin	0003_logentry_add_action_flag_choices	2025-11-13 23:39:24.264073+00
10	contenttypes	0002_remove_content_type_name	2025-11-13 23:39:24.333974+00
11	auth	0002_alter_permission_name_max_length	2025-11-13 23:39:24.376779+00
12	auth	0003_alter_user_email_max_length	2025-11-13 23:39:24.41322+00
13	auth	0004_alter_user_username_opts	2025-11-13 23:39:24.446206+00
14	auth	0005_alter_user_last_login_null	2025-11-13 23:39:24.48482+00
15	auth	0006_require_contenttypes_0002	2025-11-13 23:39:24.487493+00
16	auth	0007_alter_validators_add_error_messages	2025-11-13 23:39:24.519228+00
17	auth	0008_alter_user_username_max_length	2025-11-13 23:39:24.582551+00
18	auth	0009_alter_user_last_name_max_length	2025-11-13 23:39:24.621688+00
19	auth	0010_alter_group_name_max_length	2025-11-13 23:39:24.664584+00
20	auth	0011_update_proxy_permissions	2025-11-13 23:39:24.756586+00
21	auth	0012_alter_user_first_name_max_length	2025-11-13 23:39:24.784392+00
22	core	0001_initial	2025-11-13 23:39:25.111011+00
23	packages	0001_initial	2025-11-13 23:39:25.98599+00
24	sessions	0001_initial	2025-11-13 23:39:26.012356+00
25	packages	0002_bookinginquiry_custompackage_and_more	2025-11-14 21:04:55.061432+00
26	packages	0003_packageitinerary_end_day_number_and_more	2025-11-15 06:48:17.537074+00
27	packages	0004_custompackageitinerary	2025-11-15 10:10:46.102995+00
\.


--
-- TOC entry 3898 (class 0 OID 16886)
-- Dependencies: 267
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- TOC entry 3900 (class 0 OID 16901)
-- Dependencies: 269
-- Data for Name: packages_bookinginquiry; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_bookinginquiry (id, created_at, updated_at, inquiry_reference, customer_name, customer_email, customer_phone, country, source, preferred_travel_date, flexible_dates, alternative_date_1, alternative_date_2, number_of_adults, number_of_children, number_of_infants, budget_range, specific_budget, accommodation_preference, dietary_requirements, special_requests, prefer_email, prefer_phone, prefer_whatsapp, status, priority, staff_notes, viewed_by_staff, first_viewed_at, last_activity_at, ip_address, base_package_id, staff_assigned_id, custom_package_id) FROM stdin;
1	2025-11-15 09:14:49.092848+00	2025-11-15 22:41:23.746224+00	INQ-20251115-00001	Clarabelle Schmeler	your.email+fakedata82621@gmail.com	084-383-6616	Ireland		2026-03-19	f	2026-04-03	2025-02-28	1	2	1	under_1000	\N	budget	Adipisci eos quibusdam possimus assumenda perspiciatis.	26620 Erik Road	t	f	f	quote_sent	normal		t	2025-11-15 09:21:36.604912+00	2025-11-15 22:41:23.746268+00	172.19.0.1	1	\N	3
\.


--
-- TOC entry 3902 (class 0 OID 16914)
-- Dependencies: 271
-- Data for Name: packages_custompackage; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_custompackage (id, created_at, updated_at, custom_reference, access_token, expires_at, name, short_description, description, duration_days, duration_nights, original_price, adjusted_price, currency, modifications_made, staff_notes_to_client, staff_internal_notes, status, sent_at, first_viewed_at, last_viewed_at, view_count, approved_at, rejected_at, client_feedback, revision_number, featured_image, base_package_id, created_by_id, inquiry_id, last_modified_by_id) FROM stdin;
2	2025-11-15 12:26:44.40646+00	2025-11-15 22:21:39.161099+00	CUSTOM-2025-00002	abfc1218-9dfb-4f3a-b3d6-619a232856ef	\N	Lelah Wilkinson - Custom for Clarabelle Schmeler	Dolores mollitia quam.	Demetrius Powlowski	8	7	239.00	239.00	USD				approved	\N	2025-11-15 22:12:52.568376+00	2025-11-15 22:21:39.410281+00	6	2025-11-15 22:21:39.160931+00	\N		1		1	1	1	1
3	2025-11-15 12:37:07.958226+00	2025-11-15 22:29:35.96844+00	CUSTOM-2025-00003	098fa0ee-1748-4961-979f-a60e256d9fa1	\N	Lelah Wilkinson - Custom for Clarabelle Schmeler	Dolores mollitia quam.	Demetrius Powlowski	8	7	239.00	239.00	USD				approved	\N	2025-11-15 12:38:15.696167+00	2025-11-15 22:29:36.230071+00	3	2025-11-15 22:29:35.968249+00	\N		1		1	1	1	1
1	2025-11-15 09:45:28.185539+00	2025-11-15 22:41:23.727635+00	CUSTOM-2025-00001	8311c560-9214-4e09-8161-1729dd284de5	2025-11-22 22:41:23.726917+00	Lelah Wilkinson - Custom for Clarabelle Schmeler	Dolores mollitia quam.	Demetrius Powlowski	8	7	239.00	239.00	USD				sent	2025-11-15 22:41:23.726894+00	\N	\N	0	\N	\N		1		1	1	1	1
\.


--
-- TOC entry 3906 (class 0 OID 16998)
-- Dependencies: 275
-- Data for Name: packages_custompackageitinerary; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_custompackageitinerary (id, created_at, updated_at, day_number, end_day_number, title, description, location, accommodation_name, accommodation_type, activities, breakfast_included, lunch_included, dinner_included, transport_details, distance, drive_time, featured_image, "order", is_active, custom_package_id) FROM stdin;
1	2025-11-15 12:59:50.807954+00	2025-11-15 12:59:50.807974+00	1	\N	Arrival in arusha	Arrival in arushaArrival in arushaArrival in arusha			hotel		t	f	f					0	t	2
2	2025-11-15 12:59:50.818166+00	2025-11-15 12:59:50.8182+00	2	4	safari in serengeti	ijbfwbcpiewbew			hotel		f	f	f					0	t	2
3	2025-11-15 12:59:50.828297+00	2025-11-15 12:59:50.828327+00	5	\N	National Solutions Strategist	Mollitia aliquam officia id nihil iure aliquid repellat molestias alias.			hotel		f	t	f					0	t	2
4	2025-11-15 12:59:50.838295+00	2025-11-15 12:59:50.838331+00	6	\N	Lead Data Technician	Placeat ea culpa.			hotel		t	f	f					0	t	2
5	2025-11-15 12:59:50.84765+00	2025-11-15 12:59:50.847678+00	7	8	Chief Usability Planner	Eos mollitia praesentium necessitatibus fugit nesciunt inventore adipisci eveniet.			hotel		t	f	f					0	t	2
6	2025-11-15 22:30:29.365769+00	2025-11-15 22:30:29.365814+00	1	\N	Arrival in arusha	Arrival in arushaArrival in arushaArrival in arusha			hotel		t	f	f					0	t	1
7	2025-11-15 22:30:29.37475+00	2025-11-15 22:30:29.374778+00	2	4	safari in serengeti	ijbfwbcpiewbew			hotel		f	f	f					0	t	1
8	2025-11-15 22:30:29.381529+00	2025-11-15 22:30:29.381552+00	5	\N	National Solutions Strategist	Mollitia aliquam officia id nihil iure aliquid repellat molestias alias.			hotel		f	t	f					0	t	1
9	2025-11-15 22:30:29.388396+00	2025-11-15 22:30:29.388415+00	6	\N	Lead Data Technician	Placeat ea culpa.			hotel		t	f	f					0	t	1
10	2025-11-15 22:30:29.393925+00	2025-11-15 22:30:29.39394+00	7	8	Chief Usability Planner	Eos mollitia praesentium necessitatibus fugit nesciunt inventore adipisci eveniet.			hotel		t	f	f					0	t	1
\.


--
-- TOC entry 3904 (class 0 OID 16933)
-- Dependencies: 273
-- Data for Name: packages_inquirymessage; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_inquirymessage (id, created_at, updated_at, sender_email, sender_name, subject, message, attachment, is_internal, is_automated, is_read, read_at, inquiry_id, sender_staff_id) FROM stdin;
\.


--
-- TOC entry 3887 (class 0 OID 16757)
-- Dependencies: 256
-- Data for Name: packages_package; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_package (id, created_at, updated_at, meta_title, meta_description, meta_keywords, is_active, is_featured, "order", view_count, name, slug, description, short_description, highlights, duration_days, duration_nights, category, difficulty_level, group_size_min, group_size_max, price_per_person, currency, discount_percentage, availability_status, start_date, end_date, max_bookings, current_bookings, included_items, excluded_items, requirements, cancellation_policy, terms_and_conditions, featured_image, video_url, is_customizable, booking_count, rating_average, review_count, created_by_id) FROM stdin;
1	2025-11-14 22:02:52.836211+00	2025-11-14 22:02:52.836235+00	Lelah Wilkinson - 8D/7N Tour Package			t	f	99	8	Lelah Wilkinson	lelah-wilkinson	Demetrius Powlowski	Dolores mollitia quam.	Voluptatibus inventore aliquam et quod harum iste itaque similique eos.	8	7	trekking	extreme	1	12	239.00	USD	6.00	available	2026-02-15	2026-02-27	10	0	-accommodation	travel insurance	valid passport	Full refund if cancelled 30 days before departure. 50% refund if cancelled 15-29 days before. No refund if cancelled within 14 days.	Full refund if cancelled 30 days before departure. 50% refund if cancelled 15-29 days before. No refund if cancelled within 14 days.Full refund if cancelled 30 days before departure. 50% refund if cancelled 15-29 days before. No refund if cancelled within 14 days.	packages/Arusha_National_Park_2.jpg	\N	f	0	0.00	0	1
\.


--
-- TOC entry 3889 (class 0 OID 16778)
-- Dependencies: 258
-- Data for Name: packages_package_destinations; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_package_destinations (id, package_id, destination_id) FROM stdin;
1	1	1
2	1	2
\.


--
-- TOC entry 3891 (class 0 OID 16784)
-- Dependencies: 260
-- Data for Name: packages_packageimage; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_packageimage (id, created_at, updated_at, image, caption, "order", is_active, package_id) FROM stdin;
\.


--
-- TOC entry 3893 (class 0 OID 16790)
-- Dependencies: 262
-- Data for Name: packages_packageinclusion; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_packageinclusion (id, created_at, updated_at, inclusion_type, item_name, description, quantity, is_included, "order", is_active, package_id) FROM stdin;
\.


--
-- TOC entry 3895 (class 0 OID 16798)
-- Dependencies: 264
-- Data for Name: packages_packageitinerary; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_packageitinerary (id, created_at, updated_at, day_number, title, description, breakfast_included, lunch_included, dinner_included, highlights, notes, "order", is_active, accommodation_id, package_id, end_day_number) FROM stdin;
1	2025-11-14 22:28:13.05542+00	2025-11-14 22:28:13.055442+00	1	Arrival in arusha	Arrival in arushaArrival in arushaArrival in arusha	t	f	f			0	t	\N	1	\N
2	2025-11-15 07:28:45.56925+00	2025-11-15 07:28:45.569311+00	2	safari in serengeti	ijbfwbcpiewbew	f	f	f			0	t	\N	1	4
3	2025-11-15 12:47:54.95569+00	2025-11-15 12:47:54.955724+00	5	National Solutions Strategist	Mollitia aliquam officia id nihil iure aliquid repellat molestias alias.	f	t	f	Pariatur cumque quia.	221	0	t	\N	1	\N
4	2025-11-15 12:48:26.431876+00	2025-11-15 12:48:26.432028+00	6	Lead Data Technician	Placeat ea culpa.	t	f	f	Ducimus molestias aperiam.	138	0	t	\N	1	\N
5	2025-11-15 12:59:07.133134+00	2025-11-15 12:59:07.133178+00	7	Chief Usability Planner	Eos mollitia praesentium necessitatibus fugit nesciunt inventore adipisci eveniet.	t	f	f	Distinctio minima ut ipsam.	59	0	t	\N	1	8
\.


--
-- TOC entry 3897 (class 0 OID 16807)
-- Dependencies: 266
-- Data for Name: packages_packageitinerary_activities; Type: TABLE DATA; Schema: public; Owner: tour_admin
--

COPY public.packages_packageitinerary_activities (id, packageitinerary_id, activity_id) FROM stdin;
\.


--
-- TOC entry 3912 (class 0 OID 0)
-- Dependencies: 235
-- Name: accommodations_accommodation_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.accommodations_accommodation_id_seq', 1, true);


--
-- TOC entry 3913 (class 0 OID 0)
-- Dependencies: 237
-- Name: accommodations_accommodationimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.accommodations_accommodationimage_id_seq', 1, false);


--
-- TOC entry 3914 (class 0 OID 0)
-- Dependencies: 239
-- Name: accommodations_room_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.accommodations_room_id_seq', 1, false);


--
-- TOC entry 3915 (class 0 OID 0)
-- Dependencies: 241
-- Name: activities_activity_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.activities_activity_id_seq', 1, true);


--
-- TOC entry 3916 (class 0 OID 0)
-- Dependencies: 243
-- Name: activities_activityimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.activities_activityimage_id_seq', 1, false);


--
-- TOC entry 3917 (class 0 OID 0)
-- Dependencies: 221
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- TOC entry 3918 (class 0 OID 0)
-- Dependencies: 223
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- TOC entry 3919 (class 0 OID 0)
-- Dependencies: 219
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 100, true);


--
-- TOC entry 3920 (class 0 OID 0)
-- Dependencies: 227
-- Name: auth_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.auth_user_groups_id_seq', 1, false);


--
-- TOC entry 3921 (class 0 OID 0)
-- Dependencies: 225
-- Name: auth_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.auth_user_id_seq', 1, true);


--
-- TOC entry 3922 (class 0 OID 0)
-- Dependencies: 229
-- Name: auth_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.auth_user_user_permissions_id_seq', 1, false);


--
-- TOC entry 3923 (class 0 OID 0)
-- Dependencies: 247
-- Name: core_contactmessage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.core_contactmessage_id_seq', 1, false);


--
-- TOC entry 3924 (class 0 OID 0)
-- Dependencies: 253
-- Name: core_faq_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.core_faq_id_seq', 1, false);


--
-- TOC entry 3925 (class 0 OID 0)
-- Dependencies: 249
-- Name: core_newslettersubscriber_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.core_newslettersubscriber_id_seq', 1, false);


--
-- TOC entry 3926 (class 0 OID 0)
-- Dependencies: 251
-- Name: core_testimonial_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.core_testimonial_id_seq', 1, false);


--
-- TOC entry 3927 (class 0 OID 0)
-- Dependencies: 231
-- Name: destinations_destination_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.destinations_destination_id_seq', 3, true);


--
-- TOC entry 3928 (class 0 OID 0)
-- Dependencies: 233
-- Name: destinations_destinationimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.destinations_destinationimage_id_seq', 4, true);


--
-- TOC entry 3929 (class 0 OID 0)
-- Dependencies: 245
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- TOC entry 3930 (class 0 OID 0)
-- Dependencies: 217
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 25, true);


--
-- TOC entry 3931 (class 0 OID 0)
-- Dependencies: 215
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 27, true);


--
-- TOC entry 3932 (class 0 OID 0)
-- Dependencies: 268
-- Name: packages_bookinginquiry_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_bookinginquiry_id_seq', 1, true);


--
-- TOC entry 3933 (class 0 OID 0)
-- Dependencies: 270
-- Name: packages_custompackage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_custompackage_id_seq', 3, true);


--
-- TOC entry 3934 (class 0 OID 0)
-- Dependencies: 274
-- Name: packages_custompackageitinerary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_custompackageitinerary_id_seq', 10, true);


--
-- TOC entry 3935 (class 0 OID 0)
-- Dependencies: 272
-- Name: packages_inquirymessage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_inquirymessage_id_seq', 1, false);


--
-- TOC entry 3936 (class 0 OID 0)
-- Dependencies: 257
-- Name: packages_package_destinations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_package_destinations_id_seq', 2, true);


--
-- TOC entry 3937 (class 0 OID 0)
-- Dependencies: 255
-- Name: packages_package_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_package_id_seq', 1, true);


--
-- TOC entry 3938 (class 0 OID 0)
-- Dependencies: 259
-- Name: packages_packageimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_packageimage_id_seq', 1, false);


--
-- TOC entry 3939 (class 0 OID 0)
-- Dependencies: 261
-- Name: packages_packageinclusion_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_packageinclusion_id_seq', 1, false);


--
-- TOC entry 3940 (class 0 OID 0)
-- Dependencies: 265
-- Name: packages_packageitinerary_activities_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_packageitinerary_activities_id_seq', 1, false);


--
-- TOC entry 3941 (class 0 OID 0)
-- Dependencies: 263
-- Name: packages_packageitinerary_id_seq; Type: SEQUENCE SET; Schema: public; Owner: tour_admin
--

SELECT pg_catalog.setval('public.packages_packageitinerary_id_seq', 5, true);


--
-- TOC entry 3515 (class 2606 OID 16553)
-- Name: accommodations_accommodation accommodations_accommodation_name_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.accommodations_accommodation
    ADD CONSTRAINT accommodations_accommodation_name_key UNIQUE (name);


--
-- TOC entry 3517 (class 2606 OID 16551)
-- Name: accommodations_accommodation accommodations_accommodation_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.accommodations_accommodation
    ADD CONSTRAINT accommodations_accommodation_pkey PRIMARY KEY (id);


--
-- TOC entry 3520 (class 2606 OID 16555)
-- Name: accommodations_accommodation accommodations_accommodation_slug_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.accommodations_accommodation
    ADD CONSTRAINT accommodations_accommodation_slug_key UNIQUE (slug);


--
-- TOC entry 3523 (class 2606 OID 16561)
-- Name: accommodations_accommodationimage accommodations_accommodationimage_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.accommodations_accommodationimage
    ADD CONSTRAINT accommodations_accommodationimage_pkey PRIMARY KEY (id);


--
-- TOC entry 3526 (class 2606 OID 16571)
-- Name: accommodations_room accommodations_room_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.accommodations_room
    ADD CONSTRAINT accommodations_room_pkey PRIMARY KEY (id);


--
-- TOC entry 3542 (class 2606 OID 16624)
-- Name: activities_activity activities_activity_name_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.activities_activity
    ADD CONSTRAINT activities_activity_name_key UNIQUE (name);


--
-- TOC entry 3544 (class 2606 OID 16622)
-- Name: activities_activity activities_activity_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.activities_activity
    ADD CONSTRAINT activities_activity_pkey PRIMARY KEY (id);


--
-- TOC entry 3547 (class 2606 OID 16626)
-- Name: activities_activity activities_activity_slug_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.activities_activity
    ADD CONSTRAINT activities_activity_slug_key UNIQUE (slug);


--
-- TOC entry 3550 (class 2606 OID 16632)
-- Name: activities_activityimage activities_activityimage_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.activities_activityimage
    ADD CONSTRAINT activities_activityimage_pkey PRIMARY KEY (id);


--
-- TOC entry 3456 (class 2606 OID 16691)
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- TOC entry 3461 (class 2606 OID 16455)
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- TOC entry 3464 (class 2606 OID 16420)
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3458 (class 2606 OID 16412)
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- TOC entry 3451 (class 2606 OID 16442)
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- TOC entry 3453 (class 2606 OID 16406)
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- TOC entry 3472 (class 2606 OID 16434)
-- Name: auth_user_groups auth_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_pkey PRIMARY KEY (id);


--
-- TOC entry 3475 (class 2606 OID 16470)
-- Name: auth_user_groups auth_user_groups_user_id_group_id_94350c0c_uniq; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_group_id_94350c0c_uniq UNIQUE (user_id, group_id);


--
-- TOC entry 3466 (class 2606 OID 16426)
-- Name: auth_user auth_user_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_pkey PRIMARY KEY (id);


--
-- TOC entry 3478 (class 2606 OID 16440)
-- Name: auth_user_user_permissions auth_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_pkey PRIMARY KEY (id);


--
-- TOC entry 3481 (class 2606 OID 16484)
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_permission_id_14a6b632_uniq; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_permission_id_14a6b632_uniq UNIQUE (user_id, permission_id);


--
-- TOC entry 3469 (class 2606 OID 16686)
-- Name: auth_user auth_user_username_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user
    ADD CONSTRAINT auth_user_username_key UNIQUE (username);


--
-- TOC entry 3558 (class 2606 OID 16700)
-- Name: core_contactmessage core_contactmessage_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.core_contactmessage
    ADD CONSTRAINT core_contactmessage_pkey PRIMARY KEY (id);


--
-- TOC entry 3583 (class 2606 OID 16726)
-- Name: core_faq core_faq_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.core_faq
    ADD CONSTRAINT core_faq_pkey PRIMARY KEY (id);


--
-- TOC entry 3565 (class 2606 OID 16710)
-- Name: core_newslettersubscriber core_newslettersubscriber_email_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.core_newslettersubscriber
    ADD CONSTRAINT core_newslettersubscriber_email_key UNIQUE (email);


--
-- TOC entry 3568 (class 2606 OID 16708)
-- Name: core_newslettersubscriber core_newslettersubscriber_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.core_newslettersubscriber
    ADD CONSTRAINT core_newslettersubscriber_pkey PRIMARY KEY (id);


--
-- TOC entry 3574 (class 2606 OID 16718)
-- Name: core_testimonial core_testimonial_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.core_testimonial
    ADD CONSTRAINT core_testimonial_pkey PRIMARY KEY (id);


--
-- TOC entry 3493 (class 2606 OID 16507)
-- Name: destinations_destination destinations_destination_name_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.destinations_destination
    ADD CONSTRAINT destinations_destination_name_key UNIQUE (name);


--
-- TOC entry 3495 (class 2606 OID 16505)
-- Name: destinations_destination destinations_destination_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.destinations_destination
    ADD CONSTRAINT destinations_destination_pkey PRIMARY KEY (id);


--
-- TOC entry 3498 (class 2606 OID 16509)
-- Name: destinations_destination destinations_destination_slug_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.destinations_destination
    ADD CONSTRAINT destinations_destination_slug_key UNIQUE (slug);


--
-- TOC entry 3501 (class 2606 OID 16515)
-- Name: destinations_destinationimage destinations_destinationimage_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.destinations_destinationimage
    ADD CONSTRAINT destinations_destinationimage_pkey PRIMARY KEY (id);


--
-- TOC entry 3553 (class 2606 OID 16672)
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- TOC entry 3446 (class 2606 OID 16400)
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- TOC entry 3448 (class 2606 OID 16398)
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- TOC entry 3444 (class 2606 OID 16392)
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- TOC entry 3631 (class 2606 OID 16892)
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- TOC entry 3639 (class 2606 OID 16912)
-- Name: packages_bookinginquiry packages_bookinginquiry_inquiry_reference_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_bookinginquiry
    ADD CONSTRAINT packages_bookinginquiry_inquiry_reference_key UNIQUE (inquiry_reference);


--
-- TOC entry 3641 (class 2606 OID 16910)
-- Name: packages_bookinginquiry packages_bookinginquiry_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_bookinginquiry
    ADD CONSTRAINT packages_bookinginquiry_pkey PRIMARY KEY (id);


--
-- TOC entry 3650 (class 2606 OID 16926)
-- Name: packages_custompackage packages_custompackage_custom_reference_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_custompackage
    ADD CONSTRAINT packages_custompackage_custom_reference_key UNIQUE (custom_reference);


--
-- TOC entry 3654 (class 2606 OID 16924)
-- Name: packages_custompackage packages_custompackage_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_custompackage
    ADD CONSTRAINT packages_custompackage_pkey PRIMARY KEY (id);


--
-- TOC entry 3660 (class 2606 OID 17009)
-- Name: packages_custompackageitinerary packages_custompackageit_custom_package_id_day_nu_a3713251_uniq; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_custompackageitinerary
    ADD CONSTRAINT packages_custompackageit_custom_package_id_day_nu_a3713251_uniq UNIQUE (custom_package_id, day_number);


--
-- TOC entry 3663 (class 2606 OID 17007)
-- Name: packages_custompackageitinerary packages_custompackageitinerary_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_custompackageitinerary
    ADD CONSTRAINT packages_custompackageitinerary_pkey PRIMARY KEY (id);


--
-- TOC entry 3657 (class 2606 OID 16939)
-- Name: packages_inquirymessage packages_inquirymessage_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_inquirymessage
    ADD CONSTRAINT packages_inquirymessage_pkey PRIMARY KEY (id);


--
-- TOC entry 3606 (class 2606 OID 16835)
-- Name: packages_package_destinations packages_package_destina_package_id_destination_i_29c27924_uniq; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_package_destinations
    ADD CONSTRAINT packages_package_destina_package_id_destination_i_29c27924_uniq UNIQUE (package_id, destination_id);


--
-- TOC entry 3610 (class 2606 OID 16782)
-- Name: packages_package_destinations packages_package_destinations_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_package_destinations
    ADD CONSTRAINT packages_package_destinations_pkey PRIMARY KEY (id);


--
-- TOC entry 3598 (class 2606 OID 16774)
-- Name: packages_package packages_package_name_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_package
    ADD CONSTRAINT packages_package_name_key UNIQUE (name);


--
-- TOC entry 3601 (class 2606 OID 16772)
-- Name: packages_package packages_package_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_package
    ADD CONSTRAINT packages_package_pkey PRIMARY KEY (id);


--
-- TOC entry 3604 (class 2606 OID 16776)
-- Name: packages_package packages_package_slug_key; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_package
    ADD CONSTRAINT packages_package_slug_key UNIQUE (slug);


--
-- TOC entry 3613 (class 2606 OID 16788)
-- Name: packages_packageimage packages_packageimage_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageimage
    ADD CONSTRAINT packages_packageimage_pkey PRIMARY KEY (id);


--
-- TOC entry 3616 (class 2606 OID 16796)
-- Name: packages_packageinclusion packages_packageinclusion_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageinclusion
    ADD CONSTRAINT packages_packageinclusion_pkey PRIMARY KEY (id);


--
-- TOC entry 3624 (class 2606 OID 16873)
-- Name: packages_packageitinerary_activities packages_packageitinerar_packageitinerary_id_acti_f37a0270_uniq; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageitinerary_activities
    ADD CONSTRAINT packages_packageitinerar_packageitinerary_id_acti_f37a0270_uniq UNIQUE (packageitinerary_id, activity_id);


--
-- TOC entry 3628 (class 2606 OID 16811)
-- Name: packages_packageitinerary_activities packages_packageitinerary_activities_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageitinerary_activities
    ADD CONSTRAINT packages_packageitinerary_activities_pkey PRIMARY KEY (id);


--
-- TOC entry 3620 (class 2606 OID 16816)
-- Name: packages_packageitinerary packages_packageitinerary_package_id_day_number_151ee79e_uniq; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageitinerary
    ADD CONSTRAINT packages_packageitinerary_package_id_day_number_151ee79e_uniq UNIQUE (package_id, day_number);


--
-- TOC entry 3622 (class 2606 OID 16805)
-- Name: packages_packageitinerary packages_packageitinerary_pkey; Type: CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageitinerary
    ADD CONSTRAINT packages_packageitinerary_pkey PRIMARY KEY (id);


--
-- TOC entry 3502 (class 1259 OID 16573)
-- Name: accommodati_accommo_49a6d0_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodati_accommo_49a6d0_idx ON public.accommodations_accommodation USING btree (accommodation_type, star_rating);


--
-- TOC entry 3503 (class 1259 OID 16574)
-- Name: accommodati_destina_69bee5_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodati_destina_69bee5_idx ON public.accommodations_accommodation USING btree (destination_id, is_active);


--
-- TOC entry 3504 (class 1259 OID 16575)
-- Name: accommodati_is_feat_c3e929_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodati_is_feat_c3e929_idx ON public.accommodations_accommodation USING btree (is_featured, is_active);


--
-- TOC entry 3505 (class 1259 OID 16572)
-- Name: accommodati_name_a70e2a_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodati_name_a70e2a_idx ON public.accommodations_accommodation USING btree (name);


--
-- TOC entry 3506 (class 1259 OID 16576)
-- Name: accommodati_order_a62fa1_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodati_order_a62fa1_idx ON public.accommodations_accommodation USING btree ("order");


--
-- TOC entry 3507 (class 1259 OID 16589)
-- Name: accommodations_accommodation_accommodation_type_3b989931; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_accommodation_accommodation_type_3b989931 ON public.accommodations_accommodation USING btree (accommodation_type);


--
-- TOC entry 3508 (class 1259 OID 16590)
-- Name: accommodations_accommodation_accommodation_type_3b989931_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_accommodation_accommodation_type_3b989931_like ON public.accommodations_accommodation USING btree (accommodation_type varchar_pattern_ops);


--
-- TOC entry 3509 (class 1259 OID 16593)
-- Name: accommodations_accommodation_created_by_id_4707283b; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_accommodation_created_by_id_4707283b ON public.accommodations_accommodation USING btree (created_by_id);


--
-- TOC entry 3510 (class 1259 OID 16594)
-- Name: accommodations_accommodation_destination_id_47a4313c; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_accommodation_destination_id_47a4313c ON public.accommodations_accommodation USING btree (destination_id);


--
-- TOC entry 3511 (class 1259 OID 16592)
-- Name: accommodations_accommodation_is_active_021f06d9; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_accommodation_is_active_021f06d9 ON public.accommodations_accommodation USING btree (is_active);


--
-- TOC entry 3512 (class 1259 OID 16591)
-- Name: accommodations_accommodation_is_featured_80e98a8f; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_accommodation_is_featured_80e98a8f ON public.accommodations_accommodation USING btree (is_featured);


--
-- TOC entry 3513 (class 1259 OID 16587)
-- Name: accommodations_accommodation_name_f3886e73_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_accommodation_name_f3886e73_like ON public.accommodations_accommodation USING btree (name varchar_pattern_ops);


--
-- TOC entry 3518 (class 1259 OID 16588)
-- Name: accommodations_accommodation_slug_f043abb8_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_accommodation_slug_f043abb8_like ON public.accommodations_accommodation USING btree (slug varchar_pattern_ops);


--
-- TOC entry 3521 (class 1259 OID 16600)
-- Name: accommodations_accommodationimage_accommodation_id_2816a277; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_accommodationimage_accommodation_id_2816a277 ON public.accommodations_accommodationimage USING btree (accommodation_id);


--
-- TOC entry 3524 (class 1259 OID 16606)
-- Name: accommodations_room_accommodation_id_a7df23b4; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX accommodations_room_accommodation_id_a7df23b4 ON public.accommodations_room USING btree (accommodation_id);


--
-- TOC entry 3527 (class 1259 OID 16634)
-- Name: activities__categor_00d5d1_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities__categor_00d5d1_idx ON public.activities_activity USING btree (category, difficulty);


--
-- TOC entry 3528 (class 1259 OID 16635)
-- Name: activities__destina_883bbe_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities__destina_883bbe_idx ON public.activities_activity USING btree (destination_id, is_active);


--
-- TOC entry 3529 (class 1259 OID 16636)
-- Name: activities__is_feat_83a0dc_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities__is_feat_83a0dc_idx ON public.activities_activity USING btree (is_featured, is_active);


--
-- TOC entry 3530 (class 1259 OID 16633)
-- Name: activities__name_4db595_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities__name_4db595_idx ON public.activities_activity USING btree (name);


--
-- TOC entry 3531 (class 1259 OID 16637)
-- Name: activities__order_31f2b4_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities__order_31f2b4_idx ON public.activities_activity USING btree ("order");


--
-- TOC entry 3532 (class 1259 OID 16650)
-- Name: activities_activity_category_53f4bb81; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_category_53f4bb81 ON public.activities_activity USING btree (category);


--
-- TOC entry 3533 (class 1259 OID 16651)
-- Name: activities_activity_category_53f4bb81_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_category_53f4bb81_like ON public.activities_activity USING btree (category varchar_pattern_ops);


--
-- TOC entry 3534 (class 1259 OID 16656)
-- Name: activities_activity_created_by_id_b5334206; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_created_by_id_b5334206 ON public.activities_activity USING btree (created_by_id);


--
-- TOC entry 3535 (class 1259 OID 16657)
-- Name: activities_activity_destination_id_15d54268; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_destination_id_15d54268 ON public.activities_activity USING btree (destination_id);


--
-- TOC entry 3536 (class 1259 OID 16652)
-- Name: activities_activity_difficulty_56206264; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_difficulty_56206264 ON public.activities_activity USING btree (difficulty);


--
-- TOC entry 3537 (class 1259 OID 16653)
-- Name: activities_activity_difficulty_56206264_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_difficulty_56206264_like ON public.activities_activity USING btree (difficulty varchar_pattern_ops);


--
-- TOC entry 3538 (class 1259 OID 16655)
-- Name: activities_activity_is_active_cacf458b; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_is_active_cacf458b ON public.activities_activity USING btree (is_active);


--
-- TOC entry 3539 (class 1259 OID 16654)
-- Name: activities_activity_is_featured_f99b2415; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_is_featured_f99b2415 ON public.activities_activity USING btree (is_featured);


--
-- TOC entry 3540 (class 1259 OID 16648)
-- Name: activities_activity_name_5ebe762e_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_name_5ebe762e_like ON public.activities_activity USING btree (name varchar_pattern_ops);


--
-- TOC entry 3545 (class 1259 OID 16649)
-- Name: activities_activity_slug_15d2d0ee_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activity_slug_15d2d0ee_like ON public.activities_activity USING btree (slug varchar_pattern_ops);


--
-- TOC entry 3548 (class 1259 OID 16663)
-- Name: activities_activityimage_activity_id_869d42b9; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX activities_activityimage_activity_id_869d42b9 ON public.activities_activityimage USING btree (activity_id);


--
-- TOC entry 3454 (class 1259 OID 16692)
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- TOC entry 3459 (class 1259 OID 16466)
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- TOC entry 3462 (class 1259 OID 16467)
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- TOC entry 3449 (class 1259 OID 16449)
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- TOC entry 3470 (class 1259 OID 16482)
-- Name: auth_user_groups_group_id_97559544; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX auth_user_groups_group_id_97559544 ON public.auth_user_groups USING btree (group_id);


--
-- TOC entry 3473 (class 1259 OID 16481)
-- Name: auth_user_groups_user_id_6a12ed8b; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX auth_user_groups_user_id_6a12ed8b ON public.auth_user_groups USING btree (user_id);


--
-- TOC entry 3476 (class 1259 OID 16496)
-- Name: auth_user_user_permissions_permission_id_1fbb5f2c; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX auth_user_user_permissions_permission_id_1fbb5f2c ON public.auth_user_user_permissions USING btree (permission_id);


--
-- TOC entry 3479 (class 1259 OID 16495)
-- Name: auth_user_user_permissions_user_id_a95ead1b; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX auth_user_user_permissions_user_id_a95ead1b ON public.auth_user_user_permissions USING btree (user_id);


--
-- TOC entry 3467 (class 1259 OID 16687)
-- Name: auth_user_username_6821ab7c_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX auth_user_username_6821ab7c_like ON public.auth_user USING btree (username varchar_pattern_ops);


--
-- TOC entry 3555 (class 1259 OID 16730)
-- Name: core_contac_email_cfac76_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_contac_email_cfac76_idx ON public.core_contactmessage USING btree (email);


--
-- TOC entry 3556 (class 1259 OID 16729)
-- Name: core_contac_status_a0adbc_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_contac_status_a0adbc_idx ON public.core_contactmessage USING btree (status, created_at DESC);


--
-- TOC entry 3559 (class 1259 OID 16727)
-- Name: core_contactmessage_status_037e9912; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_contactmessage_status_037e9912 ON public.core_contactmessage USING btree (status);


--
-- TOC entry 3560 (class 1259 OID 16728)
-- Name: core_contactmessage_status_037e9912_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_contactmessage_status_037e9912_like ON public.core_contactmessage USING btree (status varchar_pattern_ops);


--
-- TOC entry 3575 (class 1259 OID 16755)
-- Name: core_faq_categor_181b73_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_faq_categor_181b73_idx ON public.core_faq USING btree (category, is_active);


--
-- TOC entry 3576 (class 1259 OID 16752)
-- Name: core_faq_category_5bf84efb; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_faq_category_5bf84efb ON public.core_faq USING btree (category);


--
-- TOC entry 3577 (class 1259 OID 16753)
-- Name: core_faq_category_5bf84efb_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_faq_category_5bf84efb_like ON public.core_faq USING btree (category varchar_pattern_ops);


--
-- TOC entry 3578 (class 1259 OID 16754)
-- Name: core_faq_created_by_id_adb5a9d1; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_faq_created_by_id_adb5a9d1 ON public.core_faq USING btree (created_by_id);


--
-- TOC entry 3579 (class 1259 OID 16749)
-- Name: core_faq_is_active_5f13c3b6; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_faq_is_active_5f13c3b6 ON public.core_faq USING btree (is_active);


--
-- TOC entry 3580 (class 1259 OID 16750)
-- Name: core_faq_is_featured_3b63be95; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_faq_is_featured_3b63be95 ON public.core_faq USING btree (is_featured);


--
-- TOC entry 3581 (class 1259 OID 16751)
-- Name: core_faq_order_16bb6561; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_faq_order_16bb6561 ON public.core_faq USING btree ("order");


--
-- TOC entry 3561 (class 1259 OID 16733)
-- Name: core_newsle_email_c74825_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_newsle_email_c74825_idx ON public.core_newslettersubscriber USING btree (email);


--
-- TOC entry 3562 (class 1259 OID 16734)
-- Name: core_newsle_is_acti_899c52_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_newsle_is_acti_899c52_idx ON public.core_newslettersubscriber USING btree (is_active, created_at DESC);


--
-- TOC entry 3563 (class 1259 OID 16731)
-- Name: core_newslettersubscriber_email_c9d9dbd8_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_newslettersubscriber_email_c9d9dbd8_like ON public.core_newslettersubscriber USING btree (email varchar_pattern_ops);


--
-- TOC entry 3566 (class 1259 OID 16732)
-- Name: core_newslettersubscriber_is_active_9140439a; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_newslettersubscriber_is_active_9140439a ON public.core_newslettersubscriber USING btree (is_active);


--
-- TOC entry 3569 (class 1259 OID 16743)
-- Name: core_testimonial_created_by_id_5f4550d7; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_testimonial_created_by_id_5f4550d7 ON public.core_testimonial USING btree (created_by_id);


--
-- TOC entry 3570 (class 1259 OID 16740)
-- Name: core_testimonial_is_active_b5980b99; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_testimonial_is_active_b5980b99 ON public.core_testimonial USING btree (is_active);


--
-- TOC entry 3571 (class 1259 OID 16741)
-- Name: core_testimonial_is_featured_bd2d39d1; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_testimonial_is_featured_bd2d39d1 ON public.core_testimonial USING btree (is_featured);


--
-- TOC entry 3572 (class 1259 OID 16742)
-- Name: core_testimonial_order_79635763; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX core_testimonial_order_79635763 ON public.core_testimonial USING btree ("order");


--
-- TOC entry 3482 (class 1259 OID 16517)
-- Name: destination_country_2ade19_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destination_country_2ade19_idx ON public.destinations_destination USING btree (country);


--
-- TOC entry 3483 (class 1259 OID 16518)
-- Name: destination_is_feat_30ec6f_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destination_is_feat_30ec6f_idx ON public.destinations_destination USING btree (is_featured, is_active);


--
-- TOC entry 3484 (class 1259 OID 16516)
-- Name: destination_name_96ccc3_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destination_name_96ccc3_idx ON public.destinations_destination USING btree (name);


--
-- TOC entry 3485 (class 1259 OID 16519)
-- Name: destination_order_5dbcec_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destination_order_5dbcec_idx ON public.destinations_destination USING btree ("order");


--
-- TOC entry 3486 (class 1259 OID 16527)
-- Name: destinations_destination_country_ad986759; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destinations_destination_country_ad986759 ON public.destinations_destination USING btree (country);


--
-- TOC entry 3487 (class 1259 OID 16532)
-- Name: destinations_destination_country_ad986759_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destinations_destination_country_ad986759_like ON public.destinations_destination USING btree (country varchar_pattern_ops);


--
-- TOC entry 3488 (class 1259 OID 16535)
-- Name: destinations_destination_created_by_id_59073026; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destinations_destination_created_by_id_59073026 ON public.destinations_destination USING btree (created_by_id);


--
-- TOC entry 3489 (class 1259 OID 16534)
-- Name: destinations_destination_is_active_6d875af2; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destinations_destination_is_active_6d875af2 ON public.destinations_destination USING btree (is_active);


--
-- TOC entry 3490 (class 1259 OID 16533)
-- Name: destinations_destination_is_featured_b6a0535b; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destinations_destination_is_featured_b6a0535b ON public.destinations_destination USING btree (is_featured);


--
-- TOC entry 3491 (class 1259 OID 16525)
-- Name: destinations_destination_name_ec7860c8_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destinations_destination_name_ec7860c8_like ON public.destinations_destination USING btree (name varchar_pattern_ops);


--
-- TOC entry 3496 (class 1259 OID 16526)
-- Name: destinations_destination_slug_92849aad_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destinations_destination_slug_92849aad_like ON public.destinations_destination USING btree (slug varchar_pattern_ops);


--
-- TOC entry 3499 (class 1259 OID 16541)
-- Name: destinations_destinationimage_destination_id_6638a3f9; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX destinations_destinationimage_destination_id_6638a3f9 ON public.destinations_destinationimage USING btree (destination_id);


--
-- TOC entry 3551 (class 1259 OID 16683)
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- TOC entry 3554 (class 1259 OID 16684)
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- TOC entry 3629 (class 1259 OID 16894)
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- TOC entry 3632 (class 1259 OID 16893)
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- TOC entry 3633 (class 1259 OID 16944)
-- Name: packages_bo_staff_a_9e6f30_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_bo_staff_a_9e6f30_idx ON public.packages_bookinginquiry USING btree (staff_assigned_id, status);


--
-- TOC entry 3634 (class 1259 OID 16943)
-- Name: packages_bo_status_c5e1b6_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_bo_status_c5e1b6_idx ON public.packages_bookinginquiry USING btree (status, created_at DESC);


--
-- TOC entry 3635 (class 1259 OID 16956)
-- Name: packages_bookinginquiry_base_package_id_85ecb013; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_bookinginquiry_base_package_id_85ecb013 ON public.packages_bookinginquiry USING btree (base_package_id);


--
-- TOC entry 3636 (class 1259 OID 16983)
-- Name: packages_bookinginquiry_custom_package_id_034376cb; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_bookinginquiry_custom_package_id_034376cb ON public.packages_bookinginquiry USING btree (custom_package_id);


--
-- TOC entry 3637 (class 1259 OID 16955)
-- Name: packages_bookinginquiry_inquiry_reference_e3ef4692_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_bookinginquiry_inquiry_reference_e3ef4692_like ON public.packages_bookinginquiry USING btree (inquiry_reference varchar_pattern_ops);


--
-- TOC entry 3642 (class 1259 OID 16957)
-- Name: packages_bookinginquiry_staff_assigned_id_fb2818cd; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_bookinginquiry_staff_assigned_id_fb2818cd ON public.packages_bookinginquiry USING btree (staff_assigned_id);


--
-- TOC entry 3643 (class 1259 OID 16942)
-- Name: packages_cu_access__bac2d3_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_cu_access__bac2d3_idx ON public.packages_custompackage USING btree (access_token);


--
-- TOC entry 3644 (class 1259 OID 16941)
-- Name: packages_cu_inquiry_af79ac_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_cu_inquiry_af79ac_idx ON public.packages_custompackage USING btree (inquiry_id, status);


--
-- TOC entry 3645 (class 1259 OID 16940)
-- Name: packages_cu_status_447856_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_cu_status_447856_idx ON public.packages_custompackage USING btree (status, created_at DESC);


--
-- TOC entry 3646 (class 1259 OID 16979)
-- Name: packages_custompackage_base_package_id_a8c81e39; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_custompackage_base_package_id_a8c81e39 ON public.packages_custompackage USING btree (base_package_id);


--
-- TOC entry 3647 (class 1259 OID 16980)
-- Name: packages_custompackage_created_by_id_67a8ded0; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_custompackage_created_by_id_67a8ded0 ON public.packages_custompackage USING btree (created_by_id);


--
-- TOC entry 3648 (class 1259 OID 16978)
-- Name: packages_custompackage_custom_reference_92582306_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_custompackage_custom_reference_92582306_like ON public.packages_custompackage USING btree (custom_reference varchar_pattern_ops);


--
-- TOC entry 3651 (class 1259 OID 16981)
-- Name: packages_custompackage_inquiry_id_d6cf9dcd; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_custompackage_inquiry_id_d6cf9dcd ON public.packages_custompackage USING btree (inquiry_id);


--
-- TOC entry 3652 (class 1259 OID 16982)
-- Name: packages_custompackage_last_modified_by_id_2b960063; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_custompackage_last_modified_by_id_2b960063 ON public.packages_custompackage USING btree (last_modified_by_id);


--
-- TOC entry 3661 (class 1259 OID 17015)
-- Name: packages_custompackageitinerary_custom_package_id_acfeebd0; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_custompackageitinerary_custom_package_id_acfeebd0 ON public.packages_custompackageitinerary USING btree (custom_package_id);


--
-- TOC entry 3655 (class 1259 OID 16994)
-- Name: packages_inquirymessage_inquiry_id_d0c696b4; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_inquirymessage_inquiry_id_d0c696b4 ON public.packages_inquirymessage USING btree (inquiry_id);


--
-- TOC entry 3658 (class 1259 OID 16995)
-- Name: packages_inquirymessage_sender_staff_id_03829bc7; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_inquirymessage_sender_staff_id_03829bc7 ON public.packages_inquirymessage USING btree (sender_staff_id);


--
-- TOC entry 3584 (class 1259 OID 16813)
-- Name: packages_pa_availab_5e2aec_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_pa_availab_5e2aec_idx ON public.packages_package USING btree (availability_status, is_active);


--
-- TOC entry 3585 (class 1259 OID 16812)
-- Name: packages_pa_categor_b32184_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_pa_categor_b32184_idx ON public.packages_package USING btree (category, is_active);


--
-- TOC entry 3586 (class 1259 OID 16814)
-- Name: packages_pa_price_p_bfe1c0_idx; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_pa_price_p_bfe1c0_idx ON public.packages_package USING btree (price_per_person);


--
-- TOC entry 3587 (class 1259 OID 16831)
-- Name: packages_package_availability_status_d57d92f3; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_availability_status_d57d92f3 ON public.packages_package USING btree (availability_status);


--
-- TOC entry 3588 (class 1259 OID 16832)
-- Name: packages_package_availability_status_d57d92f3_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_availability_status_d57d92f3_like ON public.packages_package USING btree (availability_status varchar_pattern_ops);


--
-- TOC entry 3589 (class 1259 OID 16827)
-- Name: packages_package_category_9b7db42d; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_category_9b7db42d ON public.packages_package USING btree (category);


--
-- TOC entry 3590 (class 1259 OID 16828)
-- Name: packages_package_category_9b7db42d_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_category_9b7db42d_like ON public.packages_package USING btree (category varchar_pattern_ops);


--
-- TOC entry 3591 (class 1259 OID 16833)
-- Name: packages_package_created_by_id_58883b1d; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_created_by_id_58883b1d ON public.packages_package USING btree (created_by_id);


--
-- TOC entry 3607 (class 1259 OID 16847)
-- Name: packages_package_destinations_destination_id_444f5bf3; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_destinations_destination_id_444f5bf3 ON public.packages_package_destinations USING btree (destination_id);


--
-- TOC entry 3608 (class 1259 OID 16846)
-- Name: packages_package_destinations_package_id_0006a3bf; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_destinations_package_id_0006a3bf ON public.packages_package_destinations USING btree (package_id);


--
-- TOC entry 3592 (class 1259 OID 16829)
-- Name: packages_package_difficulty_level_20e618a1; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_difficulty_level_20e618a1 ON public.packages_package USING btree (difficulty_level);


--
-- TOC entry 3593 (class 1259 OID 16830)
-- Name: packages_package_difficulty_level_20e618a1_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_difficulty_level_20e618a1_like ON public.packages_package USING btree (difficulty_level varchar_pattern_ops);


--
-- TOC entry 3594 (class 1259 OID 16822)
-- Name: packages_package_is_active_e9d4e10f; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_is_active_e9d4e10f ON public.packages_package USING btree (is_active);


--
-- TOC entry 3595 (class 1259 OID 16823)
-- Name: packages_package_is_featured_27b1a3c3; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_is_featured_27b1a3c3 ON public.packages_package USING btree (is_featured);


--
-- TOC entry 3596 (class 1259 OID 16825)
-- Name: packages_package_name_00867446_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_name_00867446_like ON public.packages_package USING btree (name varchar_pattern_ops);


--
-- TOC entry 3599 (class 1259 OID 16824)
-- Name: packages_package_order_e68c64b7; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_order_e68c64b7 ON public.packages_package USING btree ("order");


--
-- TOC entry 3602 (class 1259 OID 16826)
-- Name: packages_package_slug_520189a0_like; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_package_slug_520189a0_like ON public.packages_package USING btree (slug varchar_pattern_ops);


--
-- TOC entry 3611 (class 1259 OID 16853)
-- Name: packages_packageimage_package_id_d6d4a11c; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_packageimage_package_id_d6d4a11c ON public.packages_packageimage USING btree (package_id);


--
-- TOC entry 3614 (class 1259 OID 16859)
-- Name: packages_packageinclusion_package_id_8199e68e; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_packageinclusion_package_id_8199e68e ON public.packages_packageinclusion USING btree (package_id);


--
-- TOC entry 3625 (class 1259 OID 16884)
-- Name: packages_packageitinerary__packageitinerary_id_b89e2263; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_packageitinerary__packageitinerary_id_b89e2263 ON public.packages_packageitinerary_activities USING btree (packageitinerary_id);


--
-- TOC entry 3617 (class 1259 OID 16870)
-- Name: packages_packageitinerary_accommodation_id_9cd3b10a; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_packageitinerary_accommodation_id_9cd3b10a ON public.packages_packageitinerary USING btree (accommodation_id);


--
-- TOC entry 3626 (class 1259 OID 16885)
-- Name: packages_packageitinerary_activities_activity_id_4c13150d; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_packageitinerary_activities_activity_id_4c13150d ON public.packages_packageitinerary_activities USING btree (activity_id);


--
-- TOC entry 3618 (class 1259 OID 16871)
-- Name: packages_packageitinerary_package_id_bf27c950; Type: INDEX; Schema: public; Owner: tour_admin
--

CREATE INDEX packages_packageitinerary_package_id_bf27c950 ON public.packages_packageitinerary USING btree (package_id);


--
-- TOC entry 3675 (class 2606 OID 16595)
-- Name: accommodations_accommodationimage accommodations_accom_accommodation_id_2816a277_fk_accommoda; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.accommodations_accommodationimage
    ADD CONSTRAINT accommodations_accom_accommodation_id_2816a277_fk_accommoda FOREIGN KEY (accommodation_id) REFERENCES public.accommodations_accommodation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3673 (class 2606 OID 16577)
-- Name: accommodations_accommodation accommodations_accom_created_by_id_4707283b_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.accommodations_accommodation
    ADD CONSTRAINT accommodations_accom_created_by_id_4707283b_fk_auth_user FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3674 (class 2606 OID 16607)
-- Name: accommodations_accommodation accommodations_accom_destination_id_47a4313c_fk_destinati; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.accommodations_accommodation
    ADD CONSTRAINT accommodations_accom_destination_id_47a4313c_fk_destinati FOREIGN KEY (destination_id) REFERENCES public.destinations_destination(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3676 (class 2606 OID 16601)
-- Name: accommodations_room accommodations_room_accommodation_id_a7df23b4_fk_accommoda; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.accommodations_room
    ADD CONSTRAINT accommodations_room_accommodation_id_a7df23b4_fk_accommoda FOREIGN KEY (accommodation_id) REFERENCES public.accommodations_accommodation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3677 (class 2606 OID 16638)
-- Name: activities_activity activities_activity_created_by_id_b5334206_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.activities_activity
    ADD CONSTRAINT activities_activity_created_by_id_b5334206_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3678 (class 2606 OID 16643)
-- Name: activities_activity activities_activity_destination_id_15d54268_fk_destinati; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.activities_activity
    ADD CONSTRAINT activities_activity_destination_id_15d54268_fk_destinati FOREIGN KEY (destination_id) REFERENCES public.destinations_destination(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3679 (class 2606 OID 16658)
-- Name: activities_activityimage activities_activityi_activity_id_869d42b9_fk_activitie; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.activities_activityimage
    ADD CONSTRAINT activities_activityi_activity_id_869d42b9_fk_activitie FOREIGN KEY (activity_id) REFERENCES public.activities_activity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3665 (class 2606 OID 16461)
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3666 (class 2606 OID 16456)
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3664 (class 2606 OID 16443)
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3667 (class 2606 OID 16476)
-- Name: auth_user_groups auth_user_groups_group_id_97559544_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_group_id_97559544_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3668 (class 2606 OID 16471)
-- Name: auth_user_groups auth_user_groups_user_id_6a12ed8b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user_groups
    ADD CONSTRAINT auth_user_groups_user_id_6a12ed8b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3669 (class 2606 OID 16490)
-- Name: auth_user_user_permissions auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permi_permission_id_1fbb5f2c_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3670 (class 2606 OID 16485)
-- Name: auth_user_user_permissions auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.auth_user_user_permissions
    ADD CONSTRAINT auth_user_user_permissions_user_id_a95ead1b_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3683 (class 2606 OID 16744)
-- Name: core_faq core_faq_created_by_id_adb5a9d1_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.core_faq
    ADD CONSTRAINT core_faq_created_by_id_adb5a9d1_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3682 (class 2606 OID 16735)
-- Name: core_testimonial core_testimonial_created_by_id_5f4550d7_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.core_testimonial
    ADD CONSTRAINT core_testimonial_created_by_id_5f4550d7_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3672 (class 2606 OID 16536)
-- Name: destinations_destinationimage destinations_destina_destination_id_6638a3f9_fk_destinati; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.destinations_destinationimage
    ADD CONSTRAINT destinations_destina_destination_id_6638a3f9_fk_destinati FOREIGN KEY (destination_id) REFERENCES public.destinations_destination(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3671 (class 2606 OID 16520)
-- Name: destinations_destination destinations_destination_created_by_id_59073026_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.destinations_destination
    ADD CONSTRAINT destinations_destination_created_by_id_59073026_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3680 (class 2606 OID 16673)
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3681 (class 2606 OID 16678)
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_auth_user_id FOREIGN KEY (user_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3693 (class 2606 OID 16945)
-- Name: packages_bookinginquiry packages_bookinginqu_base_package_id_85ecb013_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_bookinginquiry
    ADD CONSTRAINT packages_bookinginqu_base_package_id_85ecb013_fk_packages_ FOREIGN KEY (base_package_id) REFERENCES public.packages_package(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3694 (class 2606 OID 16927)
-- Name: packages_bookinginquiry packages_bookinginqu_custom_package_id_034376cb_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_bookinginquiry
    ADD CONSTRAINT packages_bookinginqu_custom_package_id_034376cb_fk_packages_ FOREIGN KEY (custom_package_id) REFERENCES public.packages_custompackage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3695 (class 2606 OID 16950)
-- Name: packages_bookinginquiry packages_bookinginqu_staff_assigned_id_fb2818cd_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_bookinginquiry
    ADD CONSTRAINT packages_bookinginqu_staff_assigned_id_fb2818cd_fk_auth_user FOREIGN KEY (staff_assigned_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3696 (class 2606 OID 16958)
-- Name: packages_custompackage packages_custompacka_base_package_id_a8c81e39_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_custompackage
    ADD CONSTRAINT packages_custompacka_base_package_id_a8c81e39_fk_packages_ FOREIGN KEY (base_package_id) REFERENCES public.packages_package(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3702 (class 2606 OID 17010)
-- Name: packages_custompackageitinerary packages_custompacka_custom_package_id_acfeebd0_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_custompackageitinerary
    ADD CONSTRAINT packages_custompacka_custom_package_id_acfeebd0_fk_packages_ FOREIGN KEY (custom_package_id) REFERENCES public.packages_custompackage(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3697 (class 2606 OID 16968)
-- Name: packages_custompackage packages_custompacka_inquiry_id_d6cf9dcd_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_custompackage
    ADD CONSTRAINT packages_custompacka_inquiry_id_d6cf9dcd_fk_packages_ FOREIGN KEY (inquiry_id) REFERENCES public.packages_bookinginquiry(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3698 (class 2606 OID 16973)
-- Name: packages_custompackage packages_custompacka_last_modified_by_id_2b960063_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_custompackage
    ADD CONSTRAINT packages_custompacka_last_modified_by_id_2b960063_fk_auth_user FOREIGN KEY (last_modified_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3699 (class 2606 OID 16963)
-- Name: packages_custompackage packages_custompackage_created_by_id_67a8ded0_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_custompackage
    ADD CONSTRAINT packages_custompackage_created_by_id_67a8ded0_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3700 (class 2606 OID 16984)
-- Name: packages_inquirymessage packages_inquirymess_inquiry_id_d0c696b4_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_inquirymessage
    ADD CONSTRAINT packages_inquirymess_inquiry_id_d0c696b4_fk_packages_ FOREIGN KEY (inquiry_id) REFERENCES public.packages_bookinginquiry(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3701 (class 2606 OID 16989)
-- Name: packages_inquirymessage packages_inquirymess_sender_staff_id_03829bc7_fk_auth_user; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_inquirymessage
    ADD CONSTRAINT packages_inquirymess_sender_staff_id_03829bc7_fk_auth_user FOREIGN KEY (sender_staff_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3684 (class 2606 OID 16817)
-- Name: packages_package packages_package_created_by_id_58883b1d_fk_auth_user_id; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_package
    ADD CONSTRAINT packages_package_created_by_id_58883b1d_fk_auth_user_id FOREIGN KEY (created_by_id) REFERENCES public.auth_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3685 (class 2606 OID 16841)
-- Name: packages_package_destinations packages_package_des_destination_id_444f5bf3_fk_destinati; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_package_destinations
    ADD CONSTRAINT packages_package_des_destination_id_444f5bf3_fk_destinati FOREIGN KEY (destination_id) REFERENCES public.destinations_destination(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3686 (class 2606 OID 16836)
-- Name: packages_package_destinations packages_package_des_package_id_0006a3bf_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_package_destinations
    ADD CONSTRAINT packages_package_des_package_id_0006a3bf_fk_packages_ FOREIGN KEY (package_id) REFERENCES public.packages_package(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3687 (class 2606 OID 16848)
-- Name: packages_packageimage packages_packageimag_package_id_d6d4a11c_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageimage
    ADD CONSTRAINT packages_packageimag_package_id_d6d4a11c_fk_packages_ FOREIGN KEY (package_id) REFERENCES public.packages_package(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3688 (class 2606 OID 16854)
-- Name: packages_packageinclusion packages_packageincl_package_id_8199e68e_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageinclusion
    ADD CONSTRAINT packages_packageincl_package_id_8199e68e_fk_packages_ FOREIGN KEY (package_id) REFERENCES public.packages_package(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3689 (class 2606 OID 16860)
-- Name: packages_packageitinerary packages_packageitin_accommodation_id_9cd3b10a_fk_accommoda; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageitinerary
    ADD CONSTRAINT packages_packageitin_accommodation_id_9cd3b10a_fk_accommoda FOREIGN KEY (accommodation_id) REFERENCES public.accommodations_accommodation(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3691 (class 2606 OID 16879)
-- Name: packages_packageitinerary_activities packages_packageitin_activity_id_4c13150d_fk_activitie; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageitinerary_activities
    ADD CONSTRAINT packages_packageitin_activity_id_4c13150d_fk_activitie FOREIGN KEY (activity_id) REFERENCES public.activities_activity(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3690 (class 2606 OID 16865)
-- Name: packages_packageitinerary packages_packageitin_package_id_bf27c950_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageitinerary
    ADD CONSTRAINT packages_packageitin_package_id_bf27c950_fk_packages_ FOREIGN KEY (package_id) REFERENCES public.packages_package(id) DEFERRABLE INITIALLY DEFERRED;


--
-- TOC entry 3692 (class 2606 OID 16874)
-- Name: packages_packageitinerary_activities packages_packageitin_packageitinerary_id_b89e2263_fk_packages_; Type: FK CONSTRAINT; Schema: public; Owner: tour_admin
--

ALTER TABLE ONLY public.packages_packageitinerary_activities
    ADD CONSTRAINT packages_packageitin_packageitinerary_id_b89e2263_fk_packages_ FOREIGN KEY (packageitinerary_id) REFERENCES public.packages_packageitinerary(id) DEFERRABLE INITIALLY DEFERRED;


-- Completed on 2025-11-16 00:08:21 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict UCkUf9cntKaQAWhzKlB7sciGEbqO5RFDCwEFBCsxAXJtzsun28I8kcczluJhNdG

